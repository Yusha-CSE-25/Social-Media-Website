/* Loopr API client. Every account, post and file lives behind this site's own
   Function endpoint; nothing here reads or writes browser storage. */
(() => {
'use strict';

const BASE = '/functions/v1/app';

/* Stable application codes -> visitor-language copy. */
const COPY = {
  network_error: 'Could not reach the site. Check your connection and retry.',
  unexpected_response: 'The site replied in an unexpected way. Retry.',
  login_required: 'Your session ended — please sign in again.',
  invalid_session: 'Your session is no longer valid — please sign in again.',
  invalid_credentials: 'Wrong email or password.',
  current_password_wrong: 'Your current password is not right.',
  invalid_email: 'That email address does not look valid.',
  invalid_password: 'A password needs at least 3 characters.',
  invalid_name: 'Names are 2 to 40 characters.',
  invalid_bio: 'Bio is too long or contains unsupported characters.',
  invalid_body: 'That text is too long or contains unsupported characters.',
  invalid_reaction: 'That reaction is not available.',
  invalid_media: 'A post takes at most 6 files.',
  invalid_media_kind: 'Unsupported file kind.',
  invalid_status: 'Unknown account status.',
  invalid_role: 'Unknown role.',
  invalid_input: 'Some of the form fields need fixing.',
  unsupported_media_type: 'Unsupported file type — images: PNG, JPG, WEBP, GIF; video: MP4, WEBM.',
  invalid_media_size: 'That file is larger than the allowed limit.',
  upload_size_mismatch: 'The uploaded file did not match what was announced. Try again.',
  upload_pending: 'That file has not finished uploading.',
  upload_failed: 'The file could not be stored. Try again.',
  storage_unavailable: 'File storage is unavailable right now.',
  storage_object_not_found: 'That file is no longer stored.',
  account_suspended: 'This account is suspended by the admin.',
  email_taken: 'That email is already registered.',
  registration_unconfirmed: 'The account was not created. Try again.',
  post_unconfirmed: 'The post was not saved. Retry.',
  comment_unconfirmed: 'The reply was not saved. Retry.',
  idempotency_conflict: 'That action was already submitted with different content.',
  write_conflict: 'Something changed while saving. Retry.',
  empty_post: 'Write something or attach a file first.',
  empty_comment: 'Write a reply first.',
  rate_limited: 'Too many attempts — try again in a few minutes.',
  limiter_busy: 'Too many attempts — try again in a few minutes.',
  forbidden: 'You do not have access to that.',
  not_found: 'That is no longer here.',
  method_not_allowed: 'That action is not supported.',
  payload_too_large: 'That request is too large.',
  password_unchanged: 'Choose a password different from the current one.',
  use_settings_for_own_password: 'Use Settings to change your own password.',
  cannot_suspend_self: 'You cannot suspend your own account.',
  cannot_change_own_role: 'You cannot change your own role.',
  cannot_delete_self: 'You cannot delete the signed-in account.',
  cannot_delete_admin: 'Administrators are removed by another administrator.',
  last_admin: 'Appoint another administrator before demoting the last one.',
  use_media_url: 'That file is video — it plays through its own link.',
  service_unavailable: 'The site could not complete the request.',
  database_unavailable: 'The site database is unavailable right now.',
  database_not_configured: 'This site has no database configured yet, so accounts and posts cannot be saved.',
  count_unavailable: 'The site could not count its records.',
  function_not_configured: 'This site has no backend configured yet, so data cannot be saved.',
  application_auth_not_configured: 'This deployment has no fixed site address configured, so signing in is disabled.',
  origin_forbidden: 'That request came from another site address.',
};

function defaultCopy(status) {
  if (status === 401) return COPY.login_required;
  if (status === 403) return COPY.forbidden;
  if (status === 404) return COPY.not_found;
  if (status === 409) return COPY.write_conflict;
  if (status === 429) return COPY.rate_limited;
  if (status >= 500) return COPY.service_unavailable;
  return COPY.invalid_input;
}

class ApiError extends Error {
  constructor(code, status) {
    super(code || 'unknown_error');
    this.name = 'ApiError';
    this.code = code || 'unknown_error';
    this.status = status || 0;
    this.copy = COPY[this.code] || defaultCopy(this.status);
  }
}

async function request(path, { method = 'GET', body, key } = {}) {
  const headers = {};
  if (body !== undefined) headers['content-type'] = 'application/json';
  if (key) headers['idempotency-key'] = key;
  let response;
  try {
    response = await fetch(BASE + path, {
      method,
      headers,
      body: body === undefined ? undefined : JSON.stringify(body),
      credentials: 'same-origin',
      redirect: 'error',
      cache: 'no-store',
    });
  } catch {
    throw new ApiError('network_error', 0);
  }
  const type = response.headers.get('content-type') || '';
  let payload = null;
  if (type.includes('json')) payload = await response.json().catch(() => null);
  if (!response.ok) {
    // A failure with no JSON body never reached the Function - a static preview
    // server or proxy error page - which is not the same as a missing post.
    if (!payload) throw new ApiError('function_not_configured', response.status);
    throw new ApiError(payload.error, response.status);
  }
  return payload;
}

window.LooprAPI = {
  BASE,
  ApiError,
  copyFor: (error) => (error instanceof ApiError ? error.copy : (COPY[error && error.code] || 'Something went wrong.')),

  health: () => request('/api/health'),
  state: () => request('/api/state'),
  session: () => request('/api/session'),

  register: (body) => request('/api/register', { method: 'POST', body }),
  login: (body) => request('/api/login', { method: 'POST', body }),
  logout: () => request('/api/logout', { method: 'POST', body: {} }),

  editProfile: (patch) => request('/api/me', { method: 'PATCH', body: patch }),
  changePassword: (body) => request('/api/me/password', { method: 'POST', body }),
  removePicture: (slot) => request(`/api/me/${slot}`, { method: 'DELETE' }),

  uploadIntent: (body) => request('/api/uploads', { method: 'POST', body }),
  completeUpload: (id) => request(`/api/uploads/${id}/complete`, { method: 'POST', body: {} }),
  applyUpload: (id, slot) => request(`/api/uploads/${id}/apply`, { method: 'POST', body: { slot } }),
  // The signed URL comes only from this site's Function; the file bytes are put there as-is.
  putFile: (signedUrl, file) => fetch(signedUrl, {
    method: 'PUT',
    headers: { 'content-type': file.type || 'application/octet-stream' },
    body: file,
    credentials: 'same-origin',
  }),

  memberView: (id) => request(`/api/users/${id}/stats`),
  ownStats: () => request('/api/me/stats'),

  createPost: (body, key) => request('/api/posts', { method: 'POST', body, key }),
  deletePost: (id) => request(`/api/posts/${id}`, { method: 'DELETE' }),
  attachMedia: (id, media) => request(`/api/posts/${id}/media`, { method: 'POST', body: { media } }),
  setReaction: (id, kind) => request(`/api/posts/${id}/reaction`, { method: 'PUT', body: { kind } }),
  addComment: (id, body, key) => request(`/api/posts/${id}/comments`, { method: 'POST', body, key }),
  deleteComment: (id) => request(`/api/comments/${id}`, { method: 'DELETE' }),

  mediaDataUrl: (id) => `${BASE}/api/media/${id}/data`,
  mediaSignedUrl: (id) => request(`/api/media/${id}/url`),
  adminExportUrl: `${BASE}/api/admin/export`,

  adminOverview: () => request('/api/admin/overview'),
  adminPrune: () => request('/api/admin/prune', { method: 'POST', body: {} }),
  adminResetPassword: (id, password) => request(`/api/admin/members/${id}/password`, { method: 'POST', body: { password } }),
  adminSetStatus: (id, status) => request(`/api/admin/members/${id}/status`, { method: 'POST', body: { status } }),
  adminSetRole: (id, role) => request(`/api/admin/members/${id}/role`, { method: 'POST', body: { role } }),
  adminDeleteMember: (id) => request(`/api/admin/members/${id}`, { method: 'DELETE' }),
};
})();
