<?php
// Loopr backend entry point for PHP hosting.
//
// One file answers every call under the Function prefix, so the browser keeps using
// the exact same URLs as the Edge Function build (/functions/v1/app/api/...).
// Identity comes only from this app's own session lookup, and a failure leaves the
// server with a stable application code - never a database error, a path, or a token.
declare(strict_types=1);

namespace Loopr;

\error_reporting(E_ALL);
\ini_set('display_errors', '0');
\ini_set('log_errors', '1');

require __DIR__ . '/loopr/config.php';
require __DIR__ . '/loopr/http.php';
require __DIR__ . '/loopr/clock.php';
require __DIR__ . '/loopr/db.php';
require __DIR__ . '/loopr/validate.php';
require __DIR__ . '/loopr/auth.php';
require __DIR__ . '/loopr/limiter.php';
require __DIR__ . '/loopr/storage.php';
require __DIR__ . '/loopr/routes.php';

// Nothing reaches the visitor until the response is decided, so an error mid-request
// cannot leave a half-written body behind.
\ob_start();

try {
    route_request();
    // A streamed object has already unwound the buffers on purpose, so there is
    // nothing left to flush on that path.
    if (\ob_get_level() > 0) {
        \ob_end_flush();
    }
} catch (SessionRequired $required) {
    while (\ob_get_level() > 0) {
        \ob_end_clean();
    }
    // A session that names no row is dead: hand the cookie back for deletion.
    if ($required->state === 'invalid') {
        clear_session_cookie();
    }
    send_error(SESSION_REQUIRED, 401);
} catch (AppError $failure) {
    while (\ob_get_level() > 0) {
        \ob_end_clean();
    }
    // A suspended or revoked account loses its cookie immediately.
    if ($failure->code() === 'account_suspended') {
        clear_session_cookie();
    }
    send_error($failure->code(), $failure->status(), [], $failure->detail());
} catch (\Throwable $unexpected) {
    while (\ob_get_level() > 0) {
        \ob_end_clean();
    }
    if (\getenv('LOOPR_DEBUG') !== false) {
        // Class and source location only: no message, no parameter, no credential.
        \error_log(\sprintf('loopr failure at %s (%s:%d)', $unexpected::class, $unexpected->getFile(), $unexpected->getLine()));
    }
    send_error('service_unavailable', 503);
}
