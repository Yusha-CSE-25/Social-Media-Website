<?php
// Input normalisation and bounded validation - the PHP twin of functions/validate.mjs.
// Pure functions: no database, no I/O. Every limit, code and status matches the
// Edge Function so a visitor sees the same message whichever backend serves them.
declare(strict_types=1);

namespace Loopr;

const EMAIL_MAX_BYTES = 254;
const PASSWORD_MIN_CHARS = 3;
const PASSWORD_MAX_BYTES = 256;
const NAME_MIN_CHARS = 2;
const NAME_MAX_CHARS = 40;
const BIO_MAX_CHARS = 160;
const POST_MAX_CHARS = 2000;
const COMMENT_MAX_CHARS = 500;

const REACTION_KINDS = ['like', 'love', 'wow', 'haha', 'sad', 'mew'];
const MEDIA_SLOTS = ['image', 'video', 'avatar', 'cover'];

const IMAGE_TYPES = ['image/png', 'image/jpeg', 'image/webp', 'image/gif'];
const VIDEO_TYPES = ['video/mp4', 'video/webm'];
const PROFILE_TYPES = ['image/png', 'image/jpeg', 'image/webp'];

const MAX_IMAGE_BYTES = 5242880;
const MAX_VIDEO_BYTES = 26214400;
const MAX_PROFILE_BYTES = 1048576;

// The whitespace JavaScript's String#trim and \s agree on, so a name trimmed here is
// the same name trimmed in the browser.
const JS_SPACE = '[\\x{09}\\x{0A}\\x{0B}\\x{0C}\\x{0D}\\x{20}\\x{A0}\\x{1680}\\x{2000}-\\x{200A}'
    . '\\x{2028}\\x{2029}\\x{202F}\\x{205F}\\x{3000}\\x{FEFF}]+';

// The control characters the Edge Function refuses inside names, bios and bodies.
const CONTROL_CHARS = '/[\\x{00}-\\x{08}\\x{0B}\\x{0C}\\x{0E}-\\x{1F}\\x{7F}]/u';

function js_trim(string $value): string
{
    return (string) \preg_replace('/^' . JS_SPACE . '|' . JS_SPACE . '$/u', '', $value);
}

function js_collapse(string $value): string
{
    return (string) \preg_replace('/' . JS_SPACE . '/u', ' ', $value);
}

function has_control_chars(string $value): bool
{
    return \preg_match(CONTROL_CHARS, $value) === 1;
}

/** UTF-8 byte length, the same measure a browser pays for. */
function utf8_bytes(string $value): int
{
    return \strlen($value);
}

/** Code-point length, which is what a character limit in the UI counts. */
function char_length(string $value): int
{
    return \mb_strlen($value, 'UTF-8');
}

function is_uuid(mixed $value): bool
{
    return \is_string($value)
        && \preg_match('/^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/', $value) === 1;
}

function require_uuid(mixed $value, string $code = 'invalid_input'): string
{
    if (!is_uuid($value)) {
        throw new AppError($code, 400);
    }
    return $value;
}

function idempotency_key(): string
{
    return require_uuid((string) (header_value('idempotency-key') ?? ''), 'invalid_input');
}

function canonical_email(mixed $raw): string
{
    if (!\is_string($raw)) {
        throw new AppError('invalid_email', 400);
    }
    $email = \mb_strtolower(js_trim($raw), 'UTF-8');
    if ($email === '' || utf8_bytes($email) > EMAIL_MAX_BYTES) {
        throw new AppError('invalid_email', 400);
    }
    if (\preg_match('/^[a-z0-9._%+\-]+@[a-z0-9.\-]+\.[a-z]{2,}$/', $email) !== 1 || \strpos($email, '::') !== false) {
        throw new AppError('invalid_email', 400);
    }
    return $email;
}

function validate_password(mixed $raw): string
{
    if (!\is_string($raw)) {
        throw new AppError('invalid_password', 400);
    }
    if (char_length($raw) < PASSWORD_MIN_CHARS || utf8_bytes($raw) > PASSWORD_MAX_BYTES) {
        throw new AppError('invalid_password', 400);
    }
    return $raw;
}

/** Bounded password used before the account is known to exist. */
function bounded_password(mixed $raw): string
{
    if (!\is_string($raw) || $raw === '' || utf8_bytes($raw) > PASSWORD_MAX_BYTES) {
        throw new AppError('invalid_credentials', 401);
    }
    return $raw;
}

function validate_name(mixed $raw): string
{
    if (!\is_string($raw)) {
        throw new AppError('invalid_name', 400);
    }
    $name = js_collapse(js_trim($raw));
    $length = char_length($name);
    if ($length < NAME_MIN_CHARS || $length > NAME_MAX_CHARS || has_control_chars($name)) {
        throw new AppError('invalid_name', 400);
    }
    return $name;
}

function validate_bio(mixed $raw): string
{
    if (!\is_string($raw)) {
        return '';
    }
    $bio = \str_replace("\r", '', js_trim($raw));
    if (char_length($bio) > BIO_MAX_CHARS || has_control_chars(\str_replace("\n", '', $bio))) {
        throw new AppError('invalid_bio', 400);
    }
    return $bio;
}

function validate_body(mixed $raw, int $max_chars, string $code): string
{
    if (!\is_string($raw)) {
        throw new AppError($code, 400);
    }
    $body = js_trim(\str_replace("\r\n", "\n", $raw));
    if (char_length($body) > $max_chars || has_control_chars(\str_replace("\n", '', $body))) {
        throw new AppError($code, 400);
    }
    return $body;
}

function validate_post_body(mixed $raw): string
{
    return validate_body($raw, POST_MAX_CHARS, 'invalid_body');
}

function validate_comment_body(mixed $raw): string
{
    return validate_body($raw, COMMENT_MAX_CHARS, 'invalid_body');
}

function validate_reaction(mixed $raw): ?string
{
    if ($raw === null || $raw === '') {
        return null;
    }
    if (!\is_string($raw) || !\in_array($raw, REACTION_KINDS, true)) {
        throw new AppError('invalid_reaction', 400);
    }
    return $raw;
}

function validate_slot(mixed $raw): string
{
    if (!\is_string($raw) || !\in_array($raw, MEDIA_SLOTS, true)) {
        throw new AppError('invalid_media_kind', 400);
    }
    return $raw;
}

function validate_content_type(string $slot, mixed $raw): string
{
    $type = \is_string($raw) ? \mb_strtolower(js_trim(\explode(';', $raw)[0]), 'UTF-8') : '';
    if ($slot === 'video') {
        if (!\in_array($type, VIDEO_TYPES, true)) {
            throw new AppError('unsupported_media_type', 415);
        }
        return $type;
    }
    $allowed = ($slot === 'avatar' || $slot === 'cover') ? PROFILE_TYPES : IMAGE_TYPES;
    if (!\in_array($type, $allowed, true)) {
        throw new AppError('unsupported_media_type', 415);
    }
    return $type;
}

function allowed_types_for(string $kind): array
{
    if ($kind === 'video') {
        return VIDEO_TYPES;
    }
    return ($kind === 'avatar' || $kind === 'cover') ? PROFILE_TYPES : IMAGE_TYPES;
}

function max_bytes_for(string $slot): int
{
    if ($slot === 'video') {
        return MAX_VIDEO_BYTES;
    }
    return ($slot === 'avatar' || $slot === 'cover') ? MAX_PROFILE_BYTES : MAX_IMAGE_BYTES;
}

/** @return list<string> */
function validate_media_list(mixed $raw): array
{
    if ($raw === null) {
        return [];
    }
    if (!\is_array($raw) || \count($raw) > 6) {
        throw new AppError('invalid_media', 400);
    }
    return \array_values(\array_map(static fn (mixed $value): string => require_uuid($value, 'invalid_media'), $raw));
}

function validate_status(mixed $raw): string
{
    if ($raw !== 'active' && $raw !== 'suspended') {
        throw new AppError('invalid_status', 400);
    }
    return $raw;
}

function validate_role(mixed $raw): string
{
    if ($raw !== 'member' && $raw !== 'admin') {
        throw new AppError('invalid_role', 400);
    }
    return $raw;
}

/**
 * Display handle derived from the email local part; uniqueness is guaranteed by the
 * caller appending digits when the base form is already taken.
 */
function handle_from_email(string $email): string
{
    $local = (string) \preg_replace('/[^a-z0-9_]/', '_', \explode('@', $email)[0]);
    $cleaned = (string) \preg_replace('/^_+|_+$/', '', $local);
    $short = \substr($cleaned, 0, 20);
    if (\preg_match('/^[a-z][a-z0-9_]{1,19}$/', $short) === 1) {
        return $short;
    }
    return 'u_' . (\substr($short, 0, 18) !== '' ? \substr($short, 0, 18) : 'new');
}
