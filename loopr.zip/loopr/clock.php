<?php
// One clock for the whole backend: timestamps travel as ISO-8601 UTC strings with
// milliseconds, exactly what the Edge Function writes, so rows from either backend
// sort and parse the same way.
declare(strict_types=1);

namespace Loopr;

function now_ms(): int
{
    return (int) \floor(\microtime(true) * 1000);
}

function now_iso(): string
{
    return iso_to_string(now_ms());
}

function iso_to_string(int $ms): string
{
    return \gmdate('Y-m-d\TH:i:s', (int) \floor($ms / 1000))
        . '.' . \str_pad((string) ($ms % 1000), 3, '0', STR_PAD_LEFT) . 'Z';
}

/** Milliseconds from an ISO-8601 string, or null when it is not a usable instant. */
function iso_to_ms(mixed $value): ?int
{
    if (!\is_string($value) || $value === '') {
        return null;
    }
    try {
        $moment = new \DateTimeImmutable($value);
    } catch (\Throwable) {
        return null;
    }
    return (int) $moment->format('Uv');
}

/**
 * Day buckets for the history charts, anchored on local midnight the same way the
 * Edge Function anchors them, and labelled with the UTC month-day of that instant.
 *
 * @return list<array{label: string, from: int, to: int, n: int}>
 */
function day_buckets(array $times, int $days): array
{
    $start_of_today = \strtotime(\date('Y-m-d') . ' 00:00:00');
    if ($start_of_today === false) {
        $start_of_today = (int) \floor(time() / 86400) * 86400;
    }
    $buckets = [];
    for ($index = $days - 1; $index >= 0; $index -= 1) {
        $from = ($start_of_today - $index * 86400) * 1000;
        $buckets[] = [
            'label' => \gmdate('m-d', (int) ($from / 1000)),
            'from' => $from,
            'to' => $from + 86400000,
            'n' => 0,
        ];
    }
    foreach ($times as $value) {
        $time = iso_to_ms($value);
        if ($time === null) {
            continue;
        }
        foreach ($buckets as $position => $bucket) {
            if ($time >= $bucket['from'] && $time < $bucket['to']) {
                $buckets[$position]['n'] += 1;
                break;
            }
        }
    }
    return $buckets;
}
