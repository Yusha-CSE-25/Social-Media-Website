<?php
// Passwords and sessions.
//
// Derivation is PBKDF2-HMAC-SHA256 with the same salt size, iteration count and key
// length as the Edge Function, so one account record verifies on either backend. Only
// the salt, derived bytes and iteration count are stored: plaintext passwords are
// never persisted and never logged.
//
// A session is a 32-byte opaque token that lives only in the browser cookie; the
// database keeps its SHA-256 digest.
declare(strict_types=1);

namespace Loopr;

const PBKDF2_ITERATIONS = 120000;
const PBKDF2_ALGO = 'sha256';
const PBKDF2_KEY_BYTES = 32;
const SALT_BYTES = 16;
const TOKEN_BYTES = 32;
const MAX_COOKIE_HEADER = 8192;

const SESSION_COOKIE = '__Host-app_auth.session';
// A browser will not store a Secure cookie outside a trustworthy origin, so a
// plain-http host beyond loopback has to use the unprefixed name or the session never
// lands. The prefix is a hardening nicety; the token itself is what the database
// checks, and a value an attacker injects is one we never issued.
const INSECURE_SESSION_COOKIE = 'app_auth.session';

const TRUSTWORTHY_HOSTS = ['127.0.0.1', '[::1]', '::1', 'localhost'];

/** @return array{salt: string, hash: string, iterations: int} */
function hash_password(string $password, int $iterations = PBKDF2_ITERATIONS): array
{
    $salt = \random_bytes(SALT_BYTES);
    $derived = \hash_pbkdf2(PBKDF2_ALGO, $password, $salt, $iterations, PBKDF2_KEY_BYTES, true);
    return [
        'salt' => \base64_encode($salt),
        'hash' => \base64_encode($derived),
        'iterations' => $iterations,
    ];
}

function verify_password(string $password, mixed $salt, mixed $hash, mixed $iterations): bool
{
    $rounds = (\is_int($iterations) && $iterations > 0) ? $iterations : PBKDF2_ITERATIONS;
    if (!\is_string($salt) || !\is_string($hash)) {
        return false;
    }
    $raw_salt = \base64_decode($salt, true);
    if ($raw_salt === false) {
        return false;
    }
    $derived = \hash_pbkdf2(PBKDF2_ALGO, $password, $raw_salt, $rounds, PBKDF2_KEY_BYTES, true);
    return \hash_equals(\base64_encode($derived), $hash);
}

// Unknown accounts still pay a full derivation so response time cannot reveal whether
// an address is registered.
const DUMMY_EXPECTED = 'AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA=';

function verify_password_against_dummy(string $password): bool
{
    $derived = \hash_pbkdf2(PBKDF2_ALGO, $password, \str_repeat("\0", SALT_BYTES), PBKDF2_ITERATIONS, PBKDF2_KEY_BYTES, true);
    return \hash_equals(\base64_encode($derived), DUMMY_EXPECTED);
}

function sha256_hex(string $value): string
{
    return \hash('sha256', $value);
}

function new_session_token(): string
{
    return \rtrim(\strtr(\base64_encode(\random_bytes(TOKEN_BYTES)), '+/', '-_'), '=');
}

/** True when this request arrived on a context that may hold a Secure cookie. */
function is_trustworthy_request(): bool
{
    if (is_https()) {
        return true;
    }
    return \in_array(request_hostname(), TRUSTWORTHY_HOSTS, true);
}

function request_hostname(): string
{
    $host = request_host();
    if (\str_starts_with($host, '[')) {
        $cut = \strpos($host, ']');
        return $cut === false ? $host : \substr($host, 0, $cut + 1);
    }
    $cut = \strpos($host, ':');
    return $cut === false ? $host : \substr($host, 0, $cut);
}

function session_cookie_name(): string
{
    return is_trustworthy_request() ? SESSION_COOKIE : INSECURE_SESSION_COOKIE;
}

function set_session_cookie(string $token, int $max_age_seconds): void
{
    $secure = is_trustworthy_request() ? ' Secure;' : '';
    \header(\sprintf(
        'set-cookie: %s=%s; Path=/; HttpOnly;%s SameSite=Lax; Max-Age=%d',
        session_cookie_name(),
        $token,
        $secure,
        $max_age_seconds
    ), false);
}

function clear_session_cookie(): void
{
    $secure = is_trustworthy_request() ? ' Secure;' : '';
    \header(\sprintf(
        'set-cookie: %s=; Path=/; HttpOnly;%s SameSite=Lax; Max-Age=0',
        session_cookie_name(),
        $secure
    ), false);
}

/**
 * Only this application's own cookie is read; duplicates or oversized headers are
 * rejected rather than guessed at.
 */
function session_token_from_request(): ?string
{
    $header = header_value('cookie') ?? '';
    if ($header === '') {
        return null;
    }
    if (\strlen($header) > MAX_COOKIE_HEADER) {
        throw new AppError('invalid_credentials', 400);
    }
    $wanted = session_cookie_name();
    $values = [];
    foreach (\explode(';', $header) as $part) {
        $trimmed = \trim($part);
        $at = \strpos($trimmed, '=');
        if ($at === false || $at < 1) {
            continue;
        }
        if (\trim(\substr($trimmed, 0, $at)) === $wanted) {
            $values[] = \substr($trimmed, $at + 1);
        }
    }
    if (\count($values) === 0) {
        return null;
    }
    if (\count($values) > 1) {
        throw new AppError('invalid_credentials', 400);
    }
    $token = $values[0];
    if (\preg_match('/^[A-Za-z0-9_\-]{43}$/', $token) !== 1) {
        throw new AppError('invalid_credentials', 400);
    }
    return $token;
}

/** @return array{token: string, digest: string, expires_at: string} */
function create_session(string $user_id, ?int $now = null): array
{
    $now ??= now_ms();
    $token = new_session_token();
    $digest = sha256_hex($token);
    $expires_at = iso_to_string($now + SESSION_TTL_SECONDS * 1000);
    $created = db_exec(
        'INSERT OR IGNORE INTO sessions (token_digest, user_id, created_at, expires_at) VALUES (?, ?, ?, ?)',
        [$digest, $user_id, iso_to_string($now), $expires_at]
    );
    if ($created !== 1) {
        throw new AppError('session_unavailable', 503);
    }
    return ['token' => $token, 'digest' => $digest, 'expires_at' => $expires_at];
}

/** Re-checked on every request: cookie present -> digest lookup -> not revoked, not expired. */
function validate_session(): array
{
    $token = session_token_from_request();
    if ($token === null) {
        return ['state' => 'missing', 'session' => null];
    }
    $digest = sha256_hex($token);
    $row = db_row('SELECT token_digest, user_id, expires_at, revoked_at FROM sessions WHERE token_digest = ? LIMIT 1', [$digest]);
    if ($row === null) {
        return ['state' => 'invalid', 'session' => null];
    }
    if ($row['token_digest'] !== $digest || !\is_string($row['user_id'])) {
        return ['state' => 'invalid', 'session' => null];
    }
    if ($row['revoked_at'] !== null) {
        return ['state' => 'invalid', 'session' => null];
    }
    $expires_at = iso_to_ms($row['expires_at']);
    if ($expires_at === null || $expires_at <= now_ms()) {
        return ['state' => 'invalid', 'session' => null];
    }
    return ['state' => 'valid', 'session' => ['digest' => $digest, 'user_id' => $row['user_id'], 'expires_at' => $expires_at]];
}

function revoke_session(string $digest): bool
{
    return db_exec('UPDATE sessions SET revoked_at = ? WHERE token_digest = ?', [now_iso(), $digest]) === 1;
}

/**
 * Every other device is signed out after a credential change; the caller then
 * receives a freshly minted session instead of keeping a pre-change token.
 */
function revoke_all_sessions(string $user_id): void
{
    db_exec('UPDATE sessions SET revoked_at = ? WHERE user_id = ?', [now_iso(), $user_id]);
}
