<?php
// HTTP plumbing shared by every route: stable application errors, bounded JSON
// reads, the logical application path and the same-origin CSRF check.
//
// Application identity comes only from this app's own session lookup. No platform
// identity, no browser-supplied user id and no Host header fallback is used here.
declare(strict_types=1);

namespace Loopr;

class AppError extends \RuntimeException
{
    private string $app_code;
    private int $app_status;

    /** @var array<string, string> fixed diagnostic categories, never user data */
    private array $app_detail;

    /** @param array<string, string> $detail */
    public function __construct(string $code, int $status, array $detail = [])
    {
        parent::__construct($code, $status);
        $this->app_code = $code;
        $this->app_status = $status;
        $this->app_detail = $detail;
    }

    public function code(): string
    {
        return $this->app_code;
    }

    public function status(): int
    {
        return $this->app_status;
    }

    /** @return array<string, string> */
    public function detail(): array
    {
        return $this->app_detail;
    }
}

const NO_STORE = [
    'cache-control: private, no-store',
    'referrer-policy: no-referrer',
    'x-content-type-options: nosniff',
];

/** @param array<array-key, mixed>|list<mixed> $value */
function send_json(array $value, int $status = 200, array $extra_headers = []): void
{
    $body = \json_encode(
        $value,
        JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE | JSON_PRESERVE_ZERO_FRACTION | JSON_THROW_ON_ERROR
    );
    \http_response_code($status);
    \header('content-type: application/json');
    \header('content-length: ' . \strlen($body));
    foreach (NO_STORE as $header) {
        \header($header);
    }
    foreach ($extra_headers as $header) {
        \header($header);
    }
    echo $body;
}

/** @param array<array-key, mixed> $detail additive fields, for stable diagnostics */
function send_error(string $code, int $status, array $extra_headers = [], array $detail = []): void
{
    send_json(['error' => $code] + $detail, $status, $extra_headers);
}

/** Bytes of a stored object, with the read headers the Edge Function sends. */
function send_object(string $path, string $content_type, string $cache_control, bool $allow_ranges): void
{
    // Streamed, never buffered: a 25 MB video must not be held in memory.
    while (\ob_get_level() > 0) {
        \ob_end_flush();
    }
    $size = \filesize($path);
    if ($size === false) {
        throw new AppError('storage_unavailable', 503);
    }
    $start = 0;
    $end = $size - 1;
    $status = 200;
    $range = $_SERVER['HTTP_RANGE'] ?? '';
    if ($allow_ranges && $range !== '' && \preg_match('/^bytes=(\d*)-(\d*)$/', $range, $match) === 1) {
        if ($match[1] !== '') {
            $start = \min((int) $match[1], $size === 0 ? 0 : $size - 1);
            if ($match[2] !== '') {
                $end = \min((int) $match[2], $size - 1);
            }
        } elseif ($match[2] !== '') {
            // A suffix range asks for the last N bytes.
            $length = \min((int) $match[2], $size);
            $start = $size - $length;
        }
        if ($start <= $end) {
            $status = 206;
        } else {
            \http_response_code(416);
            \header("content-range: bytes */{$size}");
            return;
        }
    }
    \http_response_code($status);
    \header('content-type: ' . $content_type);
    \header('cache-control: ' . $cache_control);
    \header('x-content-type-options: nosniff');
    \header('referrer-policy: no-referrer');
    \header('accept-ranges: bytes');
    if ($status === 206) {
        \header('content-range: bytes ' . $start . '-' . $end . '/' . $size);
    }
    \header('content-length: ' . ($end >= $start ? $end - $start + 1 : 0));
    if (method() === 'HEAD' || $end < $start) {
        return;
    }
    $handle = @\fopen($path, 'rb');
    if ($handle === false) {
        throw new AppError('storage_unavailable', 503);
    }
    if ($start > 0) {
        \fseek($handle, $start);
    }
    $remaining = $end - $start + 1;
    while ($remaining > 0 && !\feof($handle)) {
        $chunk = \fread($handle, (int) \min(65536, $remaining));
        if ($chunk === false || $chunk === '') {
            break;
        }
        $remaining -= \strlen($chunk);
        echo $chunk;
        \flush();
    }
    \fclose($handle);
}

function method(): string
{
    return \strtoupper((string) ($_SERVER['REQUEST_METHOD'] ?? 'GET'));
}

function request_uri(): string
{
    $uri = (string) ($_SERVER['REQUEST_URI'] ?? '/');
    $cut = \strpos($uri, '?');
    return $cut === false ? $uri : \substr($uri, 0, $cut);
}

function query_value(string $name): ?string
{
    $value = $_GET[$name] ?? null;
    return is_string($value) ? $value : null;
}

function header_value(string $name): ?string
{
    $lifted = \strtoupper(\str_replace('-', '_', $name));
    foreach (['HTTP_' . $lifted, 'REDIRECT_HTTP_' . $lifted, $lifted, 'REDIRECT_' . $lifted] as $key) {
        // Apache and LiteSpeed lift Content-Type and Content-Length out of the
        // HTTP_ namespace, so a host-dependent lookup has to check both places.
        $value = $_SERVER[$key] ?? null;
        if (is_string($value) && $value !== '') {
            return $value;
        }
    }
    return null;
}

function is_https(): bool
{
    if (!empty($_SERVER['HTTPS']) && \strtolower((string) $_SERVER['HTTPS']) !== 'off') {
        return true;
    }
    if (\strtolower((string) ($_SERVER['HTTP_X_FORWARDED_PROTO'] ?? '')) === 'https') {
        return true;
    }
    return (int) ($_SERVER['SERVER_PORT'] ?? 0) === 443;
}

function request_host(): string
{
    $host = (string) ($_SERVER['HTTP_HOST'] ?? '');
    // An authority that is not a plain host[:port] is never echoed back into a
    // signed URL or an origin comparison; the fallback keeps the check fail-closed.
    if ($host !== '' && \preg_match('/^[A-Za-z0-9.\-]+(:\d{1,5})?$/', $host) === 1) {
        return $host;
    }
    $host = (string) ($_SERVER['SERVER_NAME'] ?? 'localhost');
    $port = (int) ($_SERVER['SERVER_PORT'] ?? 0);
    if ($port > 0 && $port !== (is_https() ? 443 : 80)) {
        $host .= ':' . $port;
    }
    return $host;
}

/** The origin this request arrived on - scheme plus host, with any port. */
function request_origin(): string
{
    return (is_https() ? 'https://' : 'http://') . request_host();
}

/**
 * The origin a write has to come from. A configured value is pinned exactly; with
 * none, the origin the request itself arrived on is the answer, which keeps any host
 * and any port working. Both cases still fail closed: a cross-site page can only
 * ever send its own origin, and a forged Host header makes the derived origin differ
 * from the browser's.
 */
function require_trusted_origin(): string
{
    $expected = PINNED_ORIGIN !== '' ? pinned_origin(PINNED_ORIGIN) : request_origin();
    $method = method();
    if ($method === 'OPTIONS' || $method === 'GET' || $method === 'HEAD') {
        return $expected;
    }
    if (header_value('origin') !== $expected) {
        throw new AppError('origin_forbidden', 403);
    }
    return $expected;
}

function pinned_origin(string $value): string
{
    $parts = \parse_url($value);
    if ($parts === false || !isset($parts['scheme'], $parts['host'])
        || $parts['scheme'] !== 'https'
        || (isset($parts['path']) && $parts['path'] !== '' && $parts['path'] !== '/')
        || isset($parts['user']) || isset($parts['pass']) || isset($parts['query']) || isset($parts['fragment'])) {
        throw new AppError('application_auth_not_configured', 503);
    }
    $origin = $parts['scheme'] . '://' . $parts['host'] . (isset($parts['port']) ? ':' . $parts['port'] : '');
    if ($origin !== $value) {
        throw new AppError('application_auth_not_configured', 503);
    }
    return $origin;
}

/**
 * The path the Edge Function saw after its own mount point, so one URL layout serves
 * both backends: /functions/v1/app/api/health, /app-d<hash>/api/health and /api/health
 * all mean /api/health.
 */
function application_path(): string
{
    $path = \rawurldecode(request_uri());
    if (\preg_match('#^/(?:functions/v1/)?(?:app|app-d[0-9a-f]{32})(/.*)?$#', $path, $match) === 1) {
        return $match[1] ?? '/';
    }
    throw new AppError('not_found', 404);
}

/**
 * Bounded JSON read. The bytes actually read are capped, and anything that is not a
 * JSON object is rejected - a declared Content-Length is never the limit.
 *
 * A shared host that rewrites the request internally can hand PHP an empty input
 * stream, so the body is looked for in three places and the reason is reported when
 * none of them hold it: that is the one failure an operator cannot see in a log, and
 * `body_not_forwarded` names the host rather than the app.
 *
 * @return array<string, mixed>
 */
function read_json_body(): array
{
    $type = \strtolower(\trim(\explode(';', (string) (header_value('content-type') ?? ''))[0]));
    $text = read_small_body(JSON_LIMIT_BYTES, $overflow);
    if ($overflow) {
        throw new AppError('payload_too_large', 413);
    }
    if (($text ?? '') === '') {
        $text = drain_stream('php://stdin', JSON_LIMIT_BYTES);
    }
    if (($text ?? '') === '' && $_POST !== []) {
        $text = \json_encode($_POST, JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE);
    }
    if (($text ?? '') === '') {
        throw new AppError('invalid_input', 400, [
            'reason' => $type === 'application/json' ? 'body_not_forwarded' : 'unexpected_content_type',
        ]);
    }
    if ($type !== 'application/json') {
        throw new AppError('invalid_input', 400, ['reason' => 'unexpected_content_type']);
    }
    $trimmed = \ltrim($text);
    if ($trimmed === '' || $trimmed[0] !== '{') {
        throw new AppError('invalid_input', 400, ['reason' => 'body_is_not_an_object']);
    }
    try {
        $decoded = \json_decode($text, true, 64, JSON_THROW_ON_ERROR);
    } catch (\JsonException) {
        throw new AppError('invalid_input', 400, ['reason' => 'body_is_not_json']);
    }
    if (!\is_array($decoded)) {
        throw new AppError('invalid_input', 400, ['reason' => 'body_is_not_an_object']);
    }
    return $decoded;
}

/**
 * Reads the request body into memory up to a hard cap. The bytes actually read are
 * the limit; a declared Content-Length is never trusted.
 */
function read_small_body(int $max_bytes, ?bool &$overflow = false): ?string
{
    $overflow = false;
    $handle = @\fopen('php://input', 'rb');
    if ($handle === false) {
        return null;
    }
    $text = '';
    while (!\feof($handle)) {
        $chunk = \fread($handle, 65536);
        if ($chunk === false || $chunk === '') {
            break;
        }
        if (\strlen($text) + \strlen($chunk) > $max_bytes) {
            $overflow = true;
            break;
        }
        $text .= $chunk;
    }
    \fclose($handle);
    return $overflow ? null : $text;
}

/** Best-effort second look at the request body; never longer than the cap. */
function drain_stream(string $wrapper, int $max_bytes): string
{
    $handle = @\fopen($wrapper, 'rb');
    if ($handle === false) {
        return '';
    }
    $text = '';
    while (\strlen($text) < $max_bytes && !\feof($handle)) {
        $chunk = \fread($handle, 8192);
        if ($chunk === false || $chunk === '') {
            break;
        }
        $text .= $chunk;
    }
    \fclose($handle);
    return \strlen($text) > $max_bytes ? '' : $text;
}

/**
 * Streams the request body straight to disk, so a large upload never has to fit in
 * memory. The file is renamed into place only after the byte cap held.
 *
 * @return int bytes written, or -1 when the body exceeded the cap
 */
function write_body_to_file(int $max_bytes, string $dest_path): int
{
    $handle = @\fopen('php://input', 'rb');
    if ($handle === false) {
        throw new AppError('storage_unavailable', 503);
    }
    $temp = $dest_path . '.writing';
    $out = @\fopen($temp, 'wb');
    if ($out === false) {
        \fclose($handle);
        throw new AppError('storage_unavailable', 503);
    }
    $size = 0;
    $overflow = false;
    while (!\feof($handle)) {
        $chunk = \fread($handle, 65536);
        if ($chunk === false || $chunk === '') {
            break;
        }
        $size += \strlen($chunk);
        if ($size > $max_bytes) {
            $overflow = true;
            break;
        }
        \fwrite($out, $chunk);
    }
    \fclose($handle);
    \fclose($out);
    if ($overflow) {
        @\unlink($temp);
        return -1;
    }
    if (!@\rename($temp, $dest_path)) {
        @\unlink($temp);
        throw new AppError('storage_unavailable', 503);
    }
    @\chmod($dest_path, 0640);
    return $size;
}
