<?php
// File storage on this host's own disk, outside the document root.
//
// The Edge Function asked the platform for signed upload and read URLs; a shared host
// has no platform storage, so the same URLs are issued here instead - as paths under
// this app's own /api/storage prefix, HMAC-signed so a stateless PHP process can
// check them without a ticket table. Object paths come only from the media table,
// never from a browser, and the bytes are always written under the data directory.
declare(strict_types=1);

namespace Loopr;

const OBJECT_PATH_PATTERN = '#^media/[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}/'
    . '[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}(?:\.bin)?$#';

/** @var string|null */
function storage_key(): string
{
    static $key = null;
    if ($key !== null) {
        return $key;
    }
    if (!\is_dir(DATA_DIR) && !@\mkdir(DATA_DIR, 0771, true)) {
        throw new AppError('storage_unavailable', 503);
    }
    if (\is_readable(KEY_FILE)) {
        $stored = \trim((string) @\file_get_contents(KEY_FILE));
        if (\strlen($stored) === 64 && \ctype_xdigit($stored)) {
            return $key = $stored;
        }
    }
    $key = \bin2hex(\random_bytes(32));
    if (@\file_put_contents(KEY_FILE, $key) === false) {
        throw new AppError('storage_unavailable', 503);
    }
    @\chmod(KEY_FILE, 0600);
    return $key;
}

function b64url_encode(string $bytes): string
{
    return \rtrim(\strtr(\base64_encode($bytes), '+/', '-_'), '=');
}

function b64url_decode(string $text): ?string
{
    $padded = \base64_decode(\strtr($text, '-_', '+/'), true);
    return $padded === false ? null : $padded;
}

/** A ticket authorises exactly one operation on one media row, for a bounded time. */
function issue_ticket(string $operation, string $media_id, int $ttl_seconds): string
{
    $payload = \implode('|', ['v1', $operation, $media_id, (string) (now_ms() + $ttl_seconds * 1000)]);
    $mac = \hash_hmac('sha256', $payload, storage_key(), true);
    return b64url_encode($payload) . '.' . b64url_encode($mac);
}

/** The media id a valid, unexpired ticket points at - otherwise null. */
function read_ticket(string $operation, string $token): ?string
{
    $parts = \explode('.', $token);
    if (\count($parts) !== 2) {
        return null;
    }
    $payload = b64url_decode($parts[0]);
    $mac = b64url_decode($parts[1]);
    if ($payload === null || $mac === null) {
        return null;
    }
    if (!\hash_equals(\hash_hmac('sha256', $payload, storage_key(), true), $mac)) {
        return null;
    }
    $fields = \explode('|', $payload);
    if (\count($fields) !== 4 || $fields[0] !== 'v1' || $fields[1] !== $operation || !is_uuid($fields[2])) {
        return null;
    }
    $expires_at = (int) $fields[3];
    if ($expires_at <= now_ms()) {
        return null;
    }
    return $fields[2];
}

/** Absolute path of an object, confined to the data directory. */
function object_file(string $object_path): string
{
    if (\preg_match(OBJECT_PATH_PATTERN, $object_path) !== 1) {
        throw new AppError('storage_object_not_found', 404);
    }
    $base = \realpath(DATA_DIR);
    if ($base === false) {
        throw new AppError('storage_unavailable', 503);
    }
    return $base . '/' . $object_path;
}

function object_dir_for(string $object_path): string
{
    return \dirname(object_file($object_path));
}

function storage_write(string $object_path, int $max_bytes): int
{
    $target = object_file($object_path);
    $directory = \dirname($target);
    if (!\is_dir($directory) && !@\mkdir($directory, 0770, true) && !\is_dir($directory)) {
        throw new AppError('storage_unavailable', 503);
    }
    return write_body_to_file($max_bytes, $target);
}

/** @return int bytes on disk, or -1 when the object is not there */
function storage_size(string $object_path): int
{
    $target = object_file($object_path);
    if (!\is_file($target)) {
        return -1;
    }
    $size = \filesize($target);
    return $size === false ? -1 : $size;
}

function storage_object_path(string $media_id): string
{
    $row = db_row('SELECT object_path FROM media WHERE id = ? LIMIT 1', [$media_id]);
    if ($row === null || !\is_string($row['object_path'])) {
        throw new AppError('storage_object_not_found', 404);
    }
    return $row['object_path'];
}

/** Best-effort cleanup; a failure is reported to the caller, never hidden. */
function storage_remove(array $object_paths): bool
{
    $clean = true;
    foreach ($object_paths as $path) {
        if (!\is_string($path)) {
            continue;
        }
        $target = object_file($path);
        if (\is_file($target) && !@\unlink($target)) {
            $clean = false;
        }
    }
    return $clean;
}

/**
 * Server-side only, after authorization and a successful read of the stored bytes.
 * Content type is metadata validation, not a malware or file-format inspection.
 *
 * @return array{size: int, contentType: string}
 * @throws AppError with the same codes the Edge Function maps a failed check to
 */
function verify_stored_object(array $row): array
{
    $kind = (string) $row['kind'];
    $max_bytes = max_bytes_for($kind);
    $declared = (\is_int($row['size']) && $row['size'] > 0) ? $row['size'] : $max_bytes;
    $type = \is_string($row['content_type']) ? $row['content_type'] : '';
    if (!\in_array($type, allowed_types_for($kind), true)) {
        throw new AppError('unsupported_media_type', 415);
    }
    $actual = storage_size((string) $row['object_path']);
    if ($actual < 0) {
        throw new AppError('upload_pending', 409);
    }
    if ($actual > $max_bytes) {
        throw new AppError('invalid_media_size', 413);
    }
    if ($actual !== $declared) {
        throw new AppError('upload_size_mismatch', 422);
    }
    return ['size' => $actual, 'contentType' => $type];
}

// ---- storage endpoints ---------------------------------------------------

function handle_storage_upload(string $token): void
{
    $media_id = read_ticket('upload', $token);
    if ($media_id === null) {
        send_error('storage_object_not_found', 404);
        return;
    }
    $row = db_row('SELECT id, owner_id, kind, object_path, status FROM media WHERE id = ? LIMIT 1', [$media_id]);
    if ($row === null) {
        send_error('storage_object_not_found', 404);
        return;
    }
    if (method() !== 'PUT') {
        send_error('method_not_allowed', 405);
        return;
    }
    $written = storage_write((string) $row['object_path'], max_bytes_for((string) $row['kind']));
    if ($written < 0) {
        send_error('invalid_media_size', 413);
        return;
    }
    send_json(['ok' => true]);
}

function handle_storage_read(string $token): void
{
    $media_id = read_ticket('read', $token);
    if ($media_id === null) {
        send_error('storage_object_not_found', 404);
        return;
    }
    $row = db_row('SELECT id, kind, content_type, status, object_path FROM media WHERE id = ? LIMIT 1', [$media_id]);
    if ($row === null || $row['status'] !== 'ready') {
        send_error('storage_object_not_found', 404);
        return;
    }
    $target = object_file((string) $row['object_path']);
    if (!\is_file($target)) {
        send_error('storage_object_not_found', 404);
        return;
    }
    send_object($target, (string) $row['content_type'], 'private, no-store', true);
}
