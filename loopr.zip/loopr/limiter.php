<?php
// Per-account fixed-window throttling stored in the database, so it survives
// restarts and is shared by every PHP process.
//
// Counting uses compare-and-set writes: the observed window start and count are part
// of the update predicate, so a losing concurrent writer re-reads instead of
// overwriting. An unknown write outcome is fail-closed and never replayed.
declare(strict_types=1);

namespace Loopr;

const LIMITS = [
    'login' => ['max_attempts' => 15, 'window_ms' => 900000],
    'register' => ['max_attempts' => 6, 'window_ms' => 3600000],
    'password' => ['max_attempts' => 5, 'window_ms' => 3600000],
];

const MAX_CAS_ATTEMPTS = 24;

/**
 * @return array{allowed: bool, remaining?: int, retryAfterMs?: int}
 */
function limiter_consume(string $scope, string $account, ?int $now = null): array
{
    $limit = LIMITS[$scope] ?? null;
    if ($limit === null) {
        throw new AppError('limiter_unavailable', 503);
    }
    $now ??= now_ms();
    $key = $scope . ':' . $account;

    for ($attempt = 0; $attempt < MAX_CAS_ATTEMPTS; $attempt += 1) {
        $row = db_row('SELECT key, window_started_at, attempt_count FROM auth_limiter WHERE key = ? LIMIT 1', [$key]);

        if ($row === null) {
            $inserted = db_exec(
                'INSERT OR IGNORE INTO auth_limiter (key, window_started_at, attempt_count) VALUES (?, ?, 1)',
                [$key, iso_to_string($now)]
            );
            if ($inserted === 1) {
                return ['allowed' => true, 'remaining' => $limit['max_attempts'] - 1];
            }
            continue;
        }

        $stored_window = $row['window_started_at'];
        $count = $row['attempt_count'];
        $started_at = iso_to_ms($stored_window);
        if (!\is_string($stored_window) || !\is_int($count) || $count < 0) {
            throw new AppError('limiter_unavailable', 503);
        }

        if ($started_at === null || $now - $started_at >= $limit['window_ms']) {
            $reset = db_exec(
                'UPDATE auth_limiter SET window_started_at = ?, attempt_count = 1 WHERE key = ? AND window_started_at = ?',
                [iso_to_string($now), $key, $stored_window]
            );
            if ($reset === 1) {
                return ['allowed' => true, 'remaining' => $limit['max_attempts'] - 1];
            }
            continue;
        }

        if ($count >= $limit['max_attempts']) {
            return ['allowed' => false, 'retryAfterMs' => \max(0, $started_at + $limit['window_ms'] - $now)];
        }

        $incremented = db_exec(
            'UPDATE auth_limiter SET attempt_count = ? WHERE key = ? AND window_started_at = ? AND attempt_count = ?',
            [$count + 1, $key, $stored_window, $count]
        );
        if ($incremented === 1) {
            return ['allowed' => true, 'remaining' => $limit['max_attempts'] - ($count + 1)];
        }
    }

    throw new AppError('limiter_busy', 503);
}

// Deliberately no "reset the counter after a successful login": a fixed window that
// keeps accumulating cannot be traded away for unlimited guesses.
function retry_after_headers(array $result): array
{
    return ['retry-after: ' . \max(1, (int) \ceil(((int) ($result['retryAfterMs'] ?? 0)) / 1000))];
}
