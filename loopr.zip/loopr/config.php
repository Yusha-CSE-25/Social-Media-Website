<?php
// Deployment configuration for the Loopr PHP backend.
//
// Everything here is non-secret. Credentials never live in this file: accounts are
// created through /api/register and the first confirmed account becomes the
// administrator, exactly as in the Edge Function build.
declare(strict_types=1);

namespace Loopr;

// Public address of this deployment. Empty means "answer on whatever host and port
// the request arrived on", so the same files work on localhost, a LAN address, or a
// shared host under any domain. Set it to one exact https origin only when a proxy
// rewrites the request URL and the backend can no longer see the public origin.
\define('Loopr\PINNED_ORIGIN', \getenv('LOOPR_ORIGIN') !== false ? \getenv('LOOPR_ORIGIN') : '');

// Where the SQLite file, the signing key and the uploaded bytes live. The default is
// a folder beside this code - inside htdocs on a shared host - so one upload is all
// an install needs. That is safe only because the folder is closed from the web twice
// over: db() writes a deny-all .htaccess into it, and the root .htaccess refuses
// .sqlite/.key/.sql/.bin by extension. Set LOOPR_DATA_DIR to move it outside the
// document root when the host allows a folder next to htdocs.
\define('Loopr\DATA_DIR', \rtrim(\getenv('LOOPR_DATA_DIR') !== false
  ? \getenv('LOOPR_DATA_DIR')
  : \dirname(__DIR__) . '/loopr-data', '/\\'));

\define('Loopr\DB_FILE', \rtrim(\getenv('LOOPR_DB_FILE') !== false
  ? \getenv('LOOPR_DB_FILE')
  : DATA_DIR . '/loopr.sqlite'));

// The schema travels with the backend, so the uploaded folder needs nothing beside it.
\define('Loopr\SCHEMA_FILE', __DIR__ . '/schema.sqlite.sql');

// Session lifetime in seconds - 12 hours, matching the Edge Function.
\define('Loopr\SESSION_TTL_SECONDS', 43200);

// Largest JSON request body the backend will read.
\define('Loopr\JSON_LIMIT_BYTES', 16 * 1024);

// Upload and read tickets are HMAC-signed so a stateless PHP process can verify
// them without keeping a ticket table. The signing key is generated once per
// install, stored beside the data files with owner-only permissions, and is never
// sent to a browser or written to a log.
\define('Loopr\KEY_FILE', DATA_DIR . '/storage.key');
\define('Loopr\TICKET_TTL_SECONDS', 3600);
