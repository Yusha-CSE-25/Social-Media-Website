<?php
// One SQLite connection per request, opened lazily, with the schema applied on first
// use. Statements are always prepared with bound parameters; table and column names
// come only from this file's own constants, never from a browser.
declare(strict_types=1);

namespace Loopr;

const DATA_GUARD = <<<'HTACCESS'
# Loopr keeps its database, its signing key and the uploaded bytes in this folder.
# None of it is a page and none of it may be served.
Options -Indexes
<IfModule mod_authz_core.c>
  Require all denied
</IfModule>
<IfModule !mod_authz_core.c>
  Order allow,deny
  Deny from all
</IfModule>
HTACCESS;

/**
 * The data folder normally sits inside the document root so one upload is enough,
 * which only works if the folder closes itself off. Written on every request that
 * opens the database, because a host may wipe it and an operator cannot set flags.
 */
function guard_data_directory(): void
{
    $file = DATA_DIR . '/.htaccess';
    if (\is_file($file)) {
        return;
    }
    @\file_put_contents($file, DATA_GUARD . "\n");
    @\chmod($file, 0644);
}

function db(): \PDO
{
    static $pdo = null;
    if ($pdo instanceof \PDO) {
        return $pdo;
    }
    if (!\is_dir(DATA_DIR) && !@\mkdir(DATA_DIR, 0771, true)) {
        throw new AppError('database_unavailable', 503);
    }
    guard_data_directory();
    $options = [
        \PDO::ATTR_ERRMODE => \PDO::ERRMODE_EXCEPTION,
        \PDO::ATTR_DEFAULT_FETCH_MODE => \PDO::FETCH_ASSOC,
        \PDO::ATTR_EMULATE_PREPARES => false,
        \PDO::ATTR_TIMEOUT => 8,
    ];
    try {
        $pdo = new \PDO('sqlite:' . DB_FILE, null, null, $options);
        $pdo->exec('PRAGMA foreign_keys = ON');
        $pdo->exec('PRAGMA busy_timeout = 8000');
        // Write-ahead logging keeps readers and writers apart; a host that forbids it
        // still works with the default rollback journal.
        try {
            $pdo->exec('PRAGMA journal_mode = WAL');
        } catch (\PDOException) {
            $pdo->exec('PRAGMA journal_mode = DELETE');
        }
    } catch (\PDOException) {
        throw new AppError('database_unavailable', 503);
    }
    apply_schema($pdo);
    return $pdo;
}

function apply_schema(\PDO $pdo): void
{
    try {
        $statement = $pdo->query("SELECT COUNT(*) FROM sqlite_master WHERE type = 'table' AND name = 'users'");
        if ($statement === false || (int) $statement->fetchColumn() > 0) {
            return;
        }
    } catch (\PDOException) {
        throw new AppError('database_unavailable', 503);
    }
    if (!\is_readable(SCHEMA_FILE)) {
        throw new AppError('database_unavailable', 503);
    }
    $sql = (string) \file_get_contents(SCHEMA_FILE);
    // Comment lines go first: a note may hold a semicolon, and statements are split
    // on semicolons.
    $lines = [];
    foreach (\preg_split('/\R/', $sql) ?: [] as $line) {
        $stripped = \ltrim($line);
        if ($stripped === '' || \str_starts_with($stripped, '--')) {
            continue;
        }
        $lines[] = $line;
    }
    foreach (\explode(';', \implode("\n", $lines)) as $statement) {
        $clean = \trim($statement);
        if ($clean === '') {
            continue;
        }
        try {
            $pdo->exec($clean);
        } catch (\PDOException) {
            throw new AppError('database_unavailable', 503);
        }
    }
}

/** @return list<array<string, mixed>> */
function db_rows(string $sql, array $params = []): array
{
    try {
        $statement = db()->prepare($sql);
        $statement->execute($params);
        return $statement->fetchAll();
    } catch (\PDOException) {
        throw new AppError('database_unavailable', 503);
    }
}

/** @return array<string, mixed>|null */
function db_row(string $sql, array $params = []): ?array
{
    $list = db_rows($sql, $params);
    return $list[0] ?? null;
}

/** @param array<array-key, mixed> $params */
function db_exec(string $sql, array $params = []): int
{
    try {
        $statement = db()->prepare($sql);
        $statement->execute($params);
        return $statement->rowCount();
    } catch (\PDOException) {
        throw new AppError('database_unavailable', 503);
    }
}

/** @param array<array-key, mixed> $params */
function db_value(string $sql, array $params = []): mixed
{
    try {
        $statement = db()->prepare($sql);
        $statement->execute($params);
        return $statement->fetchColumn();
    } catch (\PDOException) {
        throw new AppError('database_unavailable', 503);
    }
}

function db_count(string $table): int
{
    $guard = \preg_match('/^[a-z_]{1,32}$/', $table) === 1 ? $table : 'users';
    $value = db_value("SELECT COUNT(*) FROM \"{$guard}\"");
    if (!\is_numeric($value)) {
        throw new AppError('count_unavailable', 503);
    }
    return (int) $value;
}

/**
 * Runs the work inside a transaction so a read-then-write sequence cannot interleave
 * with another process. Nested calls use savepoints.
 */
function db_transaction(callable $work): mixed
{
    $pdo = db();
    static $depth = 0;
    $top = $depth === 0;
    try {
        if ($top) {
            $pdo->exec('BEGIN IMMEDIATE');
        } else {
            $pdo->exec('SAVEPOINT sp' . $depth);
        }
        $depth += 1;
        $result = $work();
        $depth -= 1;
        $pdo->exec($top ? 'COMMIT' : 'RELEASE SAVEPOINT sp' . $depth);
        return $result;
    } catch (\Throwable $error) {
        $depth = \max(0, $depth - 1);
        try {
            $pdo->exec($top ? 'ROLLBACK' : 'ROLLBACK TO sp' . $depth);
            if (!$top) {
                $pdo->exec('RELEASE SAVEPOINT sp' . $depth);
            }
        } catch (\PDOException) {
            // The connection is already gone; the caller's error is the one to report.
        }
        throw $error;
    }
}

/**
 * SQLite stores every column as TEXT/INTEGER/REAL/BLOB. Booleans live as 0/1 and the
 * wire shape wants true/false, so the flag columns are named here rather than
 * guessed at from a value.
 *
 * @param array<string, mixed> $row
 * @return array<string, mixed>
 */
function normalize_row(array $row): array
{
    foreach (['posts_truncated'] as $flag) {
        if (\array_key_exists($flag, $row)) {
            $row[$flag] = (bool) $row[$flag];
        }
    }
    return $row;
}
