<?php
// Loopr application routes: registration, sessions, feed, media, reactions,
// comments, statistics and the administrator panel.
//
// This is the PHP twin of functions/routes.mjs. Same paths, same wire shapes, same
// application codes and status codes. Identity is this application's own session
// (opaque cookie plus digest lookup); platform identity, browser-supplied owner ids
// and Host headers are never used.
declare(strict_types=1);

namespace Loopr;

const SESSION_REQUIRED = 'login_required';
const FEED_LIMIT = 100;
const PROFILE_POST_LIMIT = 60;
const PAGE_LIMIT = 200;
const AGGREGATE_LIMIT = 1000;
const REACTION_SCAN = 2000;
const PRUNE_GRACE_MS = 3600000;

const ACCOUNT_COLUMNS = 'id, email, name, handle, bio, role, status, created_at, last_login_at,'
    . ' login_count, avatar_media_id, cover_media_id';
const PROFILE_COLUMNS = 'id, name, handle, role, status, bio, created_at, avatar_media_id, cover_media_id';
const MEDIA_COLUMNS = 'id, post_id, owner_id, kind, content_type, size, status, object_path';
const MEDIA_WIRE_COLUMNS = 'id, owner_id, post_id, kind, content_type, size';

final class SessionRequired extends AppError
{
    public function __construct(public readonly string $state)
    {
        parent::__construct(SESSION_REQUIRED, 401);
    }
}

function uuid_v4(): string
{
    $bytes = \random_bytes(16);
    $bytes[6] = \chr((\ord($bytes[6]) & 0x0f) | 0x40);
    $bytes[8] = \chr((\ord($bytes[8]) & 0x3f) | 0x80);
    $hex = \bin2hex($bytes);
    return \substr($hex, 0, 8) . '-' . \substr($hex, 8, 4) . '-' . \substr($hex, 12, 4)
        . '-' . \substr($hex, 16, 4) . '-' . \substr($hex, 20, 12);
}

function in_marks(array $values): string
{
    return \implode(',', \array_fill(0, \count($values), '?'));
}

/** A URL on this app's own Function prefix, so the browser needs no other host. */
function app_url(string $path): string
{
    return request_origin() . '/functions/v1/app' . $path;
}

function public_user(array $row): array
{
    return [
        'id' => $row['id'],
        'name' => $row['name'],
        'handle' => $row['handle'],
        'bio' => \is_string($row['bio'] ?? null) ? $row['bio'] : '',
        'role' => $row['role'],
        'status' => $row['status'],
        'created_at' => $row['created_at'],
        'avatar_media_id' => $row['avatar_media_id'] ?? null,
        'cover_media_id' => $row['cover_media_id'] ?? null,
    ];
}

function person_row(array $row): array
{
    return [
        'id' => $row['id'], 'name' => $row['name'], 'handle' => $row['handle'], 'role' => $row['role'],
        'created_at' => $row['created_at'], 'avatar_media_id' => $row['avatar_media_id'] ?? null,
    ];
}

function profile_row(array $row): array
{
    return [
        'id' => $row['id'], 'name' => $row['name'], 'handle' => $row['handle'], 'role' => $row['role'],
        'status' => $row['status'] ?? 'active',
        'bio' => \is_string($row['bio'] ?? null) ? $row['bio'] : '',
        'joined' => $row['created_at'],
        'avatar_media_id' => $row['avatar_media_id'] ?? null,
        'cover_media_id' => $row['cover_media_id'] ?? null,
    ];
}

function media_wire(array $row): array
{
    return [
        'id' => $row['id'], 'owner' => $row['owner_id'], 'post' => $row['post_id'],
        'kind' => $row['kind'], 'type' => $row['content_type'], 'size' => $row['size'],
    ];
}

function reaction_map(array $rows): object
{
    $map = [];
    foreach ($rows as $row) {
        $map[(string) $row['user_id']] = $row['kind'];
    }
    return (object) $map;
}

// ---- data helpers --------------------------------------------------------

function find_account(string $user_id): ?array
{
    return db_row('SELECT ' . ACCOUNT_COLUMNS . ' FROM users WHERE id = ? LIMIT 1', [$user_id]);
}

/** Reached only through a session, so a missing row means the session points at an account that is gone. */
function account(string $user_id): array
{
    $found = find_account($user_id);
    if ($found === null) {
        throw new SessionRequired('invalid');
    }
    return $found;
}

function current_account(): array
{
    $result = validate_session();
    if ($result['state'] !== 'valid') {
        throw new SessionRequired($result['state']);
    }
    $user = account($result['session']['user_id']);
    if ($user['status'] !== 'active') {
        revoke_all_sessions($user['id']);
        throw new AppError('account_suspended', 403);
    }
    return ['user' => $user, 'session' => $result['session']];
}

function media_rows(array $ids): array
{
    if ($ids === []) {
        return [];
    }
    return db_rows(
        'SELECT ' . MEDIA_COLUMNS . ' FROM media WHERE id IN (' . in_marks($ids) . ') LIMIT ' . count($ids),
        $ids
    );
}

/** @param list<string> $ids */
function rows_by_ids(string $table, string $columns, string $column, array $ids, int $limit = REACTION_SCAN): array
{
    if ($ids === []) {
        return [];
    }
    $slice = \array_slice($ids, 0, $limit);
    return db_rows(
        'SELECT ' . $columns . ' FROM ' . $table . ' WHERE ' . $column . ' IN (' . in_marks($slice) . ')'
            . ' LIMIT ' . $limit,
        $slice
    );
}

// ---- auth ----------------------------------------------------------------

function handle_register(): void
{
    $body = read_json_body();
    $email = canonical_email($body['email'] ?? null);
    $name = validate_name($body['name'] ?? null);
    $password = validate_password($body['password'] ?? null);
    $limit = limiter_consume('register', $email);
    if (!$limit['allowed']) {
        send_error('rate_limited', 429, retry_after_headers($limit));
        return;
    }

    if (db_row('SELECT id FROM users WHERE email = ? LIMIT 1', [$email]) !== null) {
        send_error('email_taken', 409);
        return;
    }

    // The first confirmed account becomes the administrator; only this backend ever
    // writes a role, never a client-supplied field.
    $created = db_transaction(static function () use ($email, $name, $password): ?array {
        $bootstrap_admin = db_count('users') === 0;
        $derived = hash_password($password);
        $id = uuid_v4();
        $now = now_iso();
        $handle = unique_handle(handle_from_email($email));
        $inserted = db_exec(
            'INSERT OR IGNORE INTO users (id, email, name, handle, bio, role, status, password_salt, password_hash,'
                . ' password_iterations, created_at, login_count, last_login_at)'
                . ' VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, 1, ?)',
            [
                $id, $email, $name, $handle, '', $bootstrap_admin ? 'admin' : 'member', 'active',
                $derived['salt'], $derived['hash'], $derived['iterations'], $now, $now,
            ]
        );
        if ($inserted !== 1) {
            return null;
        }
        return db_row(
            'SELECT id, email, name, handle, bio, role, status, created_at, last_login_at, login_count'
                . ' FROM users WHERE id = ? LIMIT 1',
            [$id]
        );
    });

    if ($created === null) {
        // The email is unique, so a lost race means the address was taken in between.
        $taken = db_row('SELECT id FROM users WHERE email = ? LIMIT 1', [$email]) !== null;
        send_error($taken ? 'email_taken' : 'registration_unconfirmed', $taken ? 409 : 503);
        return;
    }

    $session = create_session($created['id']);
    set_session_cookie($session['token'], SESSION_TTL_SECONDS);
    send_json(['user' => $created], 201);
}

function unique_handle(string $base): string
{
    for ($attempt = 0; $attempt < 8; $attempt += 1) {
        $candidate = $attempt === 0 ? $base : \substr($base, 0, 16) . (100 + $attempt);
        if (db_row('SELECT id FROM users WHERE handle = ? LIMIT 1', [$candidate]) === null) {
            return $candidate;
        }
    }
    $random = \str_replace('-', '', uuid_v4());
    return \substr($base, 0, 12) . '_' . \substr($random, 0, 6);
}

function handle_login(): void
{
    $body = read_json_body();
    $email = canonical_email($body['email'] ?? null);
    $limit = limiter_consume('login', $email);
    if (!$limit['allowed']) {
        send_error('rate_limited', 429, retry_after_headers($limit));
        return;
    }
    $password = bounded_password($body['password'] ?? null);

    $user = db_row(
        'SELECT id, email, name, handle, bio, role, status, created_at, last_login_at, login_count,'
            . ' password_salt, password_hash, password_iterations FROM users WHERE email = ? LIMIT 1',
        [$email]
    );

    if ($user === null) {
        verify_password_against_dummy($password);
        send_error('invalid_credentials', 401);
        return;
    }
    if (!verify_password($password, $user['password_salt'], $user['password_hash'], $user['password_iterations'])) {
        send_error('invalid_credentials', 401);
        return;
    }
    if ($user['status'] !== 'active') {
        send_error('account_suspended', 403);
        return;
    }

    // Cosmetic counters: a lost race here must not fail an authenticated login.
    $observed = \is_int($user['login_count']) ? $user['login_count'] : 0;
    db_exec(
        'UPDATE users SET last_login_at = ?, login_count = ? WHERE id = ? AND login_count = ?',
        [now_iso(), $observed + 1, $user['id'], $observed]
    );

    $session = create_session($user['id']);
    set_session_cookie($session['token'], SESSION_TTL_SECONDS);
    send_json(['user' => public_user($user)]);
}

function handle_logout(): void
{
    $result = validate_session();
    if ($result['state'] === 'valid' && $result['session'] !== null) {
        try {
            revoke_session($result['session']['digest']);
        } catch (AppError) {
            send_error('logout_unconfirmed', 503);
            return;
        }
    }
    clear_session_cookie();
    send_json(['ok' => true]);
}

function handle_change_password(array $user): void
{
    $body = read_json_body();
    $limit = limiter_consume('password', (string) $user['email']);
    if (!$limit['allowed']) {
        send_error('rate_limited', 429, retry_after_headers($limit));
        return;
    }
    $current = bounded_password($body['currentPassword'] ?? null);
    $next = validate_password($body['nextPassword'] ?? null);
    $record = db_row('SELECT id, password_salt, password_hash, password_iterations FROM users WHERE id = ? LIMIT 1', [$user['id']]);
    if ($record === null) {
        throw new SessionRequired('invalid');
    }
    if (!verify_password($current, $record['password_salt'], $record['password_hash'], $record['password_iterations'])) {
        send_error('current_password_wrong', 401);
        return;
    }
    if ($current === $next) {
        send_error('password_unchanged', 400);
        return;
    }
    $derived = hash_password($next);
    $updated = db_exec(
        'UPDATE users SET password_salt = ?, password_hash = ?, password_iterations = ? WHERE id = ? AND password_hash = ?',
        [$derived['salt'], $derived['hash'], $derived['iterations'], $user['id'], $record['password_hash']]
    );
    if ($updated !== 1) {
        send_error('write_conflict', 409);
        return;
    }
    // Every device is signed out, then this one receives a new session.
    revoke_all_sessions($user['id']);
    $session = create_session($user['id']);
    set_session_cookie($session['token'], SESSION_TTL_SECONDS);
    send_json(['ok' => true, 'signed_out_elsewhere' => true]);
}

function handle_edit_profile(array $user): void
{
    $body = read_json_body();
    $patch = [];
    $params = [];
    if (\array_key_exists('name', $body)) {
        $patch[] = 'name = ?';
        $params[] = validate_name($body['name']);
    }
    if (\array_key_exists('bio', $body)) {
        $patch[] = 'bio = ?';
        $params[] = validate_bio($body['bio']);
    }
    if ($patch === []) {
        throw new AppError('invalid_input', 400);
    }
    $params[] = $user['id'];
    $updated = db_exec('UPDATE users SET ' . \implode(', ', $patch) . ' WHERE id = ?', $params);
    if ($updated !== 1) {
        send_error('write_conflict', 409);
        return;
    }
    $row = db_row('SELECT ' . ACCOUNT_COLUMNS . ' FROM users WHERE id = ? LIMIT 1', [$user['id']]);
    if ($row === null) {
        throw new SessionRequired('invalid');
    }
    send_json(['user' => $row]);
}

// ---- feed ----------------------------------------------------------------
// Wire shape mirrors the client's in-memory model: reactions are a {userId: kind}
// map and posts reference media ids, so the renderer never has to re-derive
// relationships.

/**
 * @param list<array<string, mixed>> $posts
 * @return array{items: list<array<string, mixed>>, media: list<array<string, mixed>>}
 */
function hydrate_posts(array $posts): array
{
    $post_ids = \array_map(static fn (array $row): string => (string) $row['id'], $posts);
    $media = $post_ids === [] ? [] : db_rows(
        'SELECT ' . MEDIA_WIRE_COLUMNS . ' FROM media WHERE status = \'ready\' AND post_id IN (' . in_marks($post_ids) . ')'
            . ' LIMIT ' . AGGREGATE_LIMIT,
        $post_ids
    );
    $reactions = rows_by_ids('reactions', 'post_id, user_id, kind', 'post_id', $post_ids);
    $comments = $post_ids === [] ? [] : db_rows(
        'SELECT id, post_id, author_id, body, created_at FROM comments WHERE post_id IN (' . in_marks($post_ids) . ')'
            . ' LIMIT ' . REACTION_SCAN,
        $post_ids
    );

    $media_by_post = [];
    foreach ($media as $row) {
        $media_by_post[(string) $row['post_id']][] = $row['id'];
    }
    $reactions_by_post = [];
    foreach ($reactions as $row) {
        $reactions_by_post[(string) $row['post_id']][] = $row;
    }
    $comments_by_post = [];
    foreach ($comments as $row) {
        $comments_by_post[(string) $row['post_id']][] = $row;
    }
    foreach ($comments_by_post as &$list) {
        \usort($list, static fn (array $a, array $b): int => \strcmp((string) $a['created_at'], (string) $b['created_at']));
    }
    unset($list);

    $items = [];
    foreach ($posts as $row) {
        $id = (string) $row['id'];
        $items[] = [
            'id' => $row['id'],
            'author' => $row['author_id'],
            'text' => $row['body'],
            'time' => $row['created_at'],
            'media' => $media_by_post[$id] ?? [],
            'reactions' => reaction_map($reactions_by_post[$id] ?? []),
            'comments' => \array_map(static fn (array $comment): array => [
                'id' => $comment['id'],
                'author' => $comment['author_id'],
                'text' => $comment['body'],
                'time' => $comment['created_at'],
            ], $comments_by_post[$id] ?? []),
        ];
    }

    return [
        'items' => $items,
        'media' => \array_map(static fn (array $row): array => media_wire($row), $media),
    ];
}

function handle_state(array $user): void
{
    $people = db_rows('SELECT ' . PROFILE_COLUMNS . ' FROM users ORDER BY created_at LIMIT ' . PAGE_LIMIT);
    $feed = hydrate_posts(db_rows(
        'SELECT id, author_id, body, created_at FROM posts ORDER BY created_at DESC LIMIT ' . FEED_LIMIT
    ));
    $stats = personal_stats($user['id']);

    // The visitor's own picture and cover belong to no post, so they are added to the
    // media map for the size the Settings card reports. Object paths stay server-side.
    $own_ids = \array_values(\array_filter([$user['avatar_media_id'] ?? null, $user['cover_media_id'] ?? null]));
    $by_id = [];
    foreach ($feed['media'] as $row) {
        $by_id[(string) $row['id']] = $row;
    }
    if ($own_ids !== []) {
        foreach (db_rows('SELECT ' . MEDIA_WIRE_COLUMNS . ' FROM media WHERE id IN (' . in_marks($own_ids) . ')', $own_ids) as $row) {
            $by_id[(string) $row['id']] = media_wire($row);
        }
    }

    send_json([
        'me' => \array_merge(profile_row($user), [
            'email' => $user['email'],
            'last_login_at' => $user['last_login_at'] ?? null,
            'login_count' => $user['login_count'] ?? 0,
            'stats' => $stats,
        ]),
        'users' => \array_map(static fn (array $row): array => profile_row($row), $people),
        'posts' => $feed['items'],
        'media' => \array_values($by_id),
        'limits' => [
            'post_max_chars' => POST_MAX_CHARS, 'comment_max_chars' => COMMENT_MAX_CHARS,
            'bio_max_chars' => BIO_MAX_CHARS, 'name_max_chars' => NAME_MAX_CHARS,
            'max_image_bytes' => MAX_IMAGE_BYTES, 'max_video_bytes' => MAX_VIDEO_BYTES,
            'max_profile_bytes' => MAX_PROFILE_BYTES, 'feed_limit' => FEED_LIMIT,
            'reaction_kinds' => REACTION_KINDS,
        ],
    ]);
}

function personal_stats(string $user_id): array
{
    $posts = db_rows('SELECT id, created_at FROM posts WHERE author_id = ? LIMIT ' . AGGREGATE_LIMIT, [$user_id]);
    $owned_media = db_rows(
        'SELECT id, size, content_type FROM media WHERE owner_id = ? AND status = \'ready\' LIMIT ' . AGGREGATE_LIMIT,
        [$user_id]
    );
    $comments_given = db_rows('SELECT id FROM comments WHERE author_id = ? LIMIT ' . AGGREGATE_LIMIT, [$user_id]);
    $post_ids = \array_map(static fn (array $row): string => (string) $row['id'], $posts);
    $reactions_received = rows_by_ids('reactions', 'post_id, user_id, kind', 'post_id', $post_ids);
    $comments_received = rows_by_ids('comments', 'id, post_id', 'post_id', $post_ids);
    $reactions_given = rows_by_ids('reactions', 'post_id, user_id, kind', 'user_id', [$user_id]);

    $mix = [];
    $bytes = 0;
    foreach ($owned_media as $row) {
        if (\is_int($row['size'])) {
            $bytes += $row['size'];
        }
    }
    foreach ($reactions_received as $row) {
        $kind = (string) $row['kind'];
        $mix[$kind] = ($mix[$kind] ?? 0) + 1;
    }

    return [
        'posts' => \count($posts),
        'media' => \count($owned_media),
        'bytes' => $bytes,
        'reactions_received' => \count($reactions_received),
        'reactions_given' => \count($reactions_given),
        'comments_given' => \count($comments_given),
        'comments_received' => \count($comments_received),
        'mix' => (object) $mix,
        'history' => \array_map(static fn (array $row): string => (string) $row['created_at'], $posts),
        'posts_truncated' => \count($posts) === AGGREGATE_LIMIT,
    ];
}

function handle_user_stats(string $user_id): void
{
    // A member who is gone is a missing resource, not a broken session: answering 401
    // here would make the browser throw away a perfectly good session cookie.
    $target = find_account($user_id);
    if ($target === null) {
        throw new AppError('not_found', 404);
    }
    $stats = personal_stats($user_id);
    $feed = hydrate_posts(db_rows(
        'SELECT id, author_id, body, created_at FROM posts WHERE author_id = ?'
            . ' ORDER BY created_at DESC LIMIT ' . PROFILE_POST_LIMIT,
        [$user_id]
    ));
    send_json([
        'user_id' => $target['id'],
        'profile' => profile_row($target),
        'last_login_at' => $target['last_login_at'] ?? null,
        'login_count' => $target['login_count'] ?? 0,
        'stats' => $stats,
        'history' => day_buckets($stats['history'], 14),
        'posts' => $feed['items'],
        'media' => $feed['media'],
        'posts_truncated' => $stats['posts_truncated'],
    ]);
}

// ---- posts ---------------------------------------------------------------

function attach_media(string $post_id, string $user_id, array $ids): array
{
    $attached = [];
    foreach ($ids as $id) {
        $found = media_rows([$id]);
        $row = $found[0] ?? null;
        if ($row === null || $row['owner_id'] !== $user_id || $row['status'] !== 'ready'
            || $row['kind'] === 'avatar' || $row['kind'] === 'cover') {
            continue;
        }
        $updated = db_exec('UPDATE media SET post_id = ? WHERE id = ? AND owner_id = ? AND status = \'ready\'',
            [$post_id, $id, $user_id]);
        if ($updated === 1) {
            $attached[] = $id;
        }
    }
    return $attached;
}

function handle_create_post(array $user): void
{
    $body = read_json_body();
    $text = validate_post_body($body['body'] ?? $body['text'] ?? '');
    $ids = validate_media_list($body['media'] ?? null);
    if ($text === '' && $ids === []) {
        throw new AppError('empty_post', 400);
    }
    $key = idempotency_key();
    $id = uuid_v4();
    $now = now_iso();

    $outcome = db_transaction(static function () use ($user, $text, $key, $id, $now): array {
        $inserted = db_exec(
            'INSERT OR IGNORE INTO posts (id, author_id, body, idempotency_key, created_at) VALUES (?, ?, ?, ?, ?)',
            [$id, $user['id'], $text, $key, $now]
        );
        if ($inserted === 1) {
            $row = db_row('SELECT id, author_id, body, created_at FROM posts WHERE id = ? LIMIT 1', [$id]);
            if ($row === null) {
                throw new AppError('post_unconfirmed', 503);
            }
            return ['post' => $row, 'status' => 201];
        }
        // Same key + same content recovers the committed row; anything else conflicts.
        $existing = db_row(
            'SELECT id, author_id, body, created_at FROM posts WHERE author_id = ? AND idempotency_key = ? LIMIT 1',
            [$user['id'], $key]
        );
        if ($existing === null) {
            throw new AppError('post_unconfirmed', 503);
        }
        if ($existing['body'] !== $text) {
            throw new AppError('idempotency_conflict', 409);
        }
        return ['post' => $existing, 'status' => 200];
    });

    $attached = attach_media((string) $outcome['post']['id'], (string) $user['id'], $ids);
    send_json([
        'post' => $outcome['post'],
        'attached' => $attached,
        'media_pending' => \array_values(\array_filter($ids, static fn (string $id): bool => !\in_array($id, $attached, true))),
    ], $outcome['status']);
}

function handle_attach_media(array $user, string $post_id): void
{
    $body = read_json_body();
    $ids = validate_media_list($body['media'] ?? null);
    if ($ids === []) {
        throw new AppError('invalid_media', 400);
    }
    $post = db_row('SELECT id, author_id FROM posts WHERE id = ? LIMIT 1', [$post_id]);
    if ($post === null) {
        send_error('not_found', 404);
        return;
    }
    if ($post['author_id'] !== $user['id'] && $user['role'] !== 'admin') {
        throw new AppError('forbidden', 403);
    }
    $attached = attach_media($post_id, (string) $post['author_id'], $ids);
    send_json([
        'attached' => $attached,
        'media_pending' => \array_values(\array_filter($ids, static fn (string $id): bool => !\in_array($id, $attached, true))),
    ]);
}

function handle_delete_post(array $user, string $post_id): void
{
    $post = db_row('SELECT id, author_id FROM posts WHERE id = ? LIMIT 1', [$post_id]);
    if ($post === null) {
        send_error('not_found', 404);
        return;
    }
    if ($post['author_id'] !== $user['id'] && $user['role'] !== 'admin') {
        throw new AppError('forbidden', 403);
    }
    $objects = db_rows('SELECT id, object_path FROM media WHERE post_id = ? LIMIT ' . AGGREGATE_LIMIT, [$post_id]);
    $deleted = db_transaction(static fn (): int => db_exec(
        'DELETE FROM posts WHERE id = ? AND author_id = ?',
        [$post_id, $post['author_id']]
    ));
    if ($deleted !== 1) {
        send_error('write_conflict', 409);
        return;
    }
    // Media rows disappear with the post; the objects are cleaned best-effort.
    if ($objects !== []) {
        $cleaned = storage_remove(\array_map(static fn (array $row): string => (string) $row['object_path'], $objects));
        if (!$cleaned) {
            storage_remove(\array_map(static fn (array $row): string => (string) $row['object_path'], $objects));
        }
    }
    send_json(['ok' => true, 'media_removed' => \count($objects)]);
}

function handle_set_reaction(array $user, string $post_id): void
{
    $body = read_json_body();
    $kind = validate_reaction($body['kind'] ?? null);
    if (db_row('SELECT id FROM posts WHERE id = ? LIMIT 1', [$post_id]) === null) {
        send_error('not_found', 404);
        return;
    }

    db_transaction(static function () use ($post_id, $user, $kind): void {
        if ($kind === null) {
            db_exec('DELETE FROM reactions WHERE post_id = ? AND user_id = ?', [$post_id, $user['id']]);
            return;
        }
        $found = db_row('SELECT post_id, user_id, kind FROM reactions WHERE post_id = ? AND user_id = ? LIMIT 1',
            [$post_id, $user['id']]);
        if ($found !== null) {
            if ($found['kind'] !== $kind) {
                $changed = db_exec('UPDATE reactions SET kind = ? WHERE post_id = ? AND user_id = ? AND kind = ?',
                    [$kind, $post_id, $user['id'], $found['kind']]);
                if ($changed !== 1) {
                    throw new AppError('write_conflict', 409);
                }
            }
            return;
        }
        $inserted = db_exec('INSERT OR IGNORE INTO reactions (post_id, user_id, kind, created_at) VALUES (?, ?, ?, ?)',
            [$post_id, $user['id'], $kind, now_iso()]);
        if ($inserted !== 1) {
            throw new AppError('write_conflict', 409);
        }
    });

    $all = db_rows('SELECT post_id, user_id, kind FROM reactions WHERE post_id = ? LIMIT ' . REACTION_SCAN, [$post_id]);
    send_json(['post_id' => $post_id, 'reactions' => reaction_map($all)]);
}

function handle_add_comment(array $user, string $post_id): void
{
    $body = read_json_body();
    $text = validate_comment_body($body['body'] ?? $body['text'] ?? '');
    if ($text === '') {
        throw new AppError('empty_comment', 400);
    }
    $key = idempotency_key();
    if (db_row('SELECT id FROM posts WHERE id = ? LIMIT 1', [$post_id]) === null) {
        send_error('not_found', 404);
        return;
    }
    $id = uuid_v4();
    $now = now_iso();
    $outcome = db_transaction(static function () use ($post_id, $user, $text, $key, $id, $now): array {
        $inserted = db_exec(
            'INSERT OR IGNORE INTO comments (id, post_id, author_id, body, idempotency_key, created_at)'
                . ' VALUES (?, ?, ?, ?, ?, ?)',
            [$id, $post_id, $user['id'], $text, $key, $now]
        );
        if ($inserted === 1) {
            $row = db_row('SELECT id, post_id, author_id, body, created_at FROM comments WHERE id = ? LIMIT 1', [$id]);
            if ($row === null) {
                throw new AppError('comment_unconfirmed', 503);
            }
            return ['comment' => $row, 'status' => 201];
        }
        $existing = db_row(
            'SELECT id, post_id, author_id, body, created_at FROM comments'
                . ' WHERE post_id = ? AND author_id = ? AND idempotency_key = ? LIMIT 1',
            [$post_id, $user['id'], $key]
        );
        if ($existing === null) {
            throw new AppError('comment_unconfirmed', 503);
        }
        if ($existing['body'] !== $text) {
            throw new AppError('idempotency_conflict', 409);
        }
        return ['comment' => $existing, 'status' => 200];
    });
    send_json(['comment' => $outcome['comment'], 'author' => person_row($user)], $outcome['status']);
}

function handle_delete_comment(array $user, string $comment_id): void
{
    $found = db_row('SELECT id, author_id FROM comments WHERE id = ? LIMIT 1', [$comment_id]);
    if ($found === null) {
        send_error('not_found', 404);
        return;
    }
    if ($found['author_id'] !== $user['id'] && $user['role'] !== 'admin') {
        throw new AppError('forbidden', 403);
    }
    $deleted = db_exec('DELETE FROM comments WHERE id = ? AND author_id = ?', [$comment_id, $found['author_id']]);
    if ($deleted !== 1) {
        send_error('write_conflict', 409);
        return;
    }
    send_json(['ok' => true]);
}

// ---- media ---------------------------------------------------------------

function handle_upload_intent(array $user): void
{
    $body = read_json_body();
    $slot = validate_slot($body['kind'] ?? null);
    $content_type = validate_content_type($slot, $body['contentType'] ?? null);
    $size = \is_int($body['size'] ?? null) ? $body['size'] : -1;
    $max = max_bytes_for($slot);
    if ($size <= 0 || $size > $max) {
        throw new AppError('invalid_media_size', 413);
    }
    $id = uuid_v4();
    // The .bin suffix is deliberate: an uploaded file has no content type of its own
    // in its name, and the root .htaccess refuses .bin by extension, so the bytes stay
    // unserved even if the data folder's own guard is ever lost.
    $object_path = 'media/' . $user['id'] . '/' . $id . '.bin';
    // The declared size is only a claim until the stored bytes are read back.
    db_exec(
        'INSERT OR IGNORE INTO media (id, owner_id, post_id, object_path, kind, content_type, size, status, created_at)'
            . ' VALUES (?, ?, NULL, ?, ?, ?, ?, \'pending\', ?)',
        [$id, $user['id'], $object_path, $slot, $content_type, $size, now_iso()]
    );
    send_json([
        'id' => $id,
        'kind' => $slot,
        'size' => $size,
        'max_bytes' => $max,
        'signedUrl' => app_url('/api/storage/upload/' . issue_ticket('upload', $id, 900)),
    ], 201);
}

function handle_complete_upload(array $user, string $upload_id): void
{
    $found = media_rows([$upload_id]);
    $row = $found[0] ?? null;
    if ($row === null || $row['owner_id'] !== $user['id']) {
        send_error('not_found', 404);
        return;
    }
    if ($row['status'] === 'ready') {
        send_json([
            'id' => $row['id'], 'kind' => $row['kind'], 'status' => 'ready',
            'size' => $row['size'], 'content_type' => $row['content_type'],
        ]);
        return;
    }
    $actual = verify_stored_object($row);
    $updated = db_exec(
        'UPDATE media SET status = \'ready\', size = ?, content_type = ?'
            . ' WHERE id = ? AND owner_id = ? AND status = \'pending\'',
        [$actual['size'], $actual['contentType'], $row['id'], $user['id']]
    );
    if ($updated !== 1) {
        send_error('write_conflict', 409);
        return;
    }
    send_json([
        'id' => $row['id'], 'kind' => $row['kind'], 'status' => 'ready',
        'size' => $actual['size'], 'content_type' => $actual['contentType'],
    ]);
}

/** A completed object is verified before it becomes the live profile picture. */
function handle_apply_upload(array $user, string $upload_id): void
{
    $body = read_json_body();
    $slot = validate_slot($body['slot'] ?? null);
    if ($slot !== 'avatar' && $slot !== 'cover') {
        throw new AppError('invalid_media_kind', 400);
    }
    $found = media_rows([$upload_id]);
    $row = $found[0] ?? null;
    if ($row === null || $row['owner_id'] !== $user['id']) {
        send_error('not_found', 404);
        return;
    }
    if ($row['status'] !== 'ready') {
        send_error('upload_pending', 409);
        return;
    }
    if ($row['kind'] !== $slot) {
        throw new AppError('invalid_media_kind', 400);
    }
    $column = $slot === 'avatar' ? 'avatar_media_id' : 'cover_media_id';
    $previous = $user[$column] ?? null;
    $updated = db_exec('UPDATE users SET ' . $column . ' = ? WHERE id = ?', [$row['id'], $user['id']]);
    if ($updated !== 1) {
        send_error('write_conflict', 409);
        return;
    }
    if ($previous !== null) {
        discard_media([$previous], (string) $user['id']);
    }
    send_json(['ok' => true, 'slot' => $slot, 'media_id' => $row['id']]);
}

function handle_remove_profile_media(array $user, string $slot): void
{
    if ($slot !== 'avatar' && $slot !== 'cover') {
        throw new AppError('invalid_media_kind', 400);
    }
    $column = $slot === 'avatar' ? 'avatar_media_id' : 'cover_media_id';
    $current = $user[$column] ?? null;
    db_exec('UPDATE users SET ' . $column . ' = NULL WHERE id = ?', [$user['id']]);
    if ($current !== null) {
        discard_media([$current], (string) $user['id']);
    }
    send_json(['ok' => true, 'slot' => $slot]);
}

function discard_media(array $ids, string $owner_id): array
{
    $found = media_rows($ids);
    $owned = \array_values(\array_filter($found, static fn (array $row): bool => $row['owner_id'] === $owner_id));
    if ($owned === []) {
        return [];
    }
    $owned_ids = \array_map(static fn (array $row): string => (string) $row['id'], $owned);
    db_exec('DELETE FROM media WHERE id IN (' . in_marks($owned_ids) . ')', $owned_ids);
    $paths = \array_map(static fn (array $row): string => (string) $row['object_path'], $owned);
    if (!storage_remove($paths)) {
        // Deleting a row already happened; a failed object removal is retried once and
        // otherwise left for the prune tool rather than reported as a successful delete.
        storage_remove($paths);
    }
    return $owned_ids;
}

// Explicit application read policy: once an object is verified and ready, every
// signed-in visitor may view it, because Loopr's feed is shared across the site.
// Rows that are still pending are never readable, and paths come only from the media
// table - never from a browser-supplied path.
function handle_media_data(string $media_id): void
{
    $found = media_rows([$media_id]);
    $row = $found[0] ?? null;
    if ($row === null) {
        send_error('not_found', 404);
        return;
    }
    if ($row['status'] !== 'ready') {
        send_error('upload_pending', 409);
        return;
    }
    if ($row['kind'] === 'video') {
        send_error('use_media_url', 409);
        return;
    }
    $target = object_file((string) $row['object_path']);
    if (!\is_file($target)) {
        throw new AppError('storage_unavailable', 503);
    }
    send_object($target, (string) $row['content_type'], 'private, max-age=300', false);
}

function handle_media_url(string $media_id): void
{
    $found = media_rows([$media_id]);
    $row = $found[0] ?? null;
    if ($row === null) {
        send_error('not_found', 404);
        return;
    }
    if ($row['status'] !== 'ready') {
        send_error('upload_pending', 409);
        return;
    }
    if ($row['kind'] !== 'video') {
        send_error('invalid_media_kind', 400);
        return;
    }
    $expires_at = now_ms() + 3600000;
    send_json([
        'signedUrl' => app_url('/api/storage/object/' . issue_ticket('read', $media_id, 3600)),
        'expiresAt' => iso_to_string($expires_at),
    ]);
}

// ---- administration ------------------------------------------------------

function handle_admin_overview(): void
{
    $users = db_count('users');
    $posts = db_count('posts');
    $media = db_count('media');
    $comments = db_count('comments');
    $reactions = db_rows('SELECT post_id, user_id, kind FROM reactions LIMIT ' . REACTION_SCAN);

    $members = db_rows('SELECT id, email, name, handle, role, status, created_at, last_login_at, login_count,'
        . ' avatar_media_id, cover_media_id FROM users ORDER BY created_at LIMIT ' . PAGE_LIMIT);
    $post_rows = db_rows('SELECT id, author_id, created_at FROM posts ORDER BY created_at DESC LIMIT ' . AGGREGATE_LIMIT);
    $ready_media = db_rows('SELECT id, owner_id, size, status, kind, created_at, post_id FROM media'
        . ' WHERE status = \'ready\' LIMIT ' . AGGREGATE_LIMIT);

    $reaction_rows_by_post = [];
    foreach ($reactions as $row) {
        $reaction_rows_by_post[(string) $row['post_id']][] = $row;
    }
    $reactions_by_author = [];
    $posts_by_author = [];
    foreach ($post_rows as $post) {
        $count = \count($reaction_rows_by_post[(string) $post['id']] ?? []);
        $author = (string) $post['author_id'];
        $reactions_by_author[$author] = ($reactions_by_author[$author] ?? 0) + $count;
        $posts_by_author[$author] = ($posts_by_author[$author] ?? 0) + 1;
    }
    $bytes_by_owner = [];
    $total_bytes = 0;
    foreach ($ready_media as $row) {
        $size = \is_int($row['size']) ? $row['size'] : 0;
        $total_bytes += $size;
        $owner = (string) $row['owner_id'];
        $bytes_by_owner[$owner] = ($bytes_by_owner[$owner] ?? 0) + $size;
    }
    $mix = [];
    foreach ($reactions as $row) {
        $kind = (string) $row['kind'];
        $mix[$kind] = ($mix[$kind] ?? 0) + 1;
    }

    send_json([
        'site' => [
            'users' => $users,
            'posts' => $posts,
            'media' => $media,
            'comments' => $comments,
            'reactions' => \count($reactions),
            'bytes' => $total_bytes,
            'history' => day_buckets(\array_map(
                static fn (array $row): string => (string) $row['created_at'], $post_rows), 14),
            'mix' => (object) $mix,
            'truncated' => $posts > \count($post_rows) || $media > \count($ready_media),
        ],
        'members' => \array_map(static fn (array $row): array => \array_merge(public_user($row), [
            'email' => $row['email'],
            'last_login_at' => $row['last_login_at'] ?? null,
            'login_count' => \is_int($row['login_count']) ? $row['login_count'] : 0,
            'posts_recent' => $posts_by_author[(string) $row['id']] ?? 0,
            'reactions_recent' => $reactions_by_author[(string) $row['id']] ?? 0,
            'bytes' => $bytes_by_owner[(string) $row['id']] ?? 0,
        ]), $members),
        'posts' => admin_post_rows(),
        'limits' => ['page_limit' => PAGE_LIMIT, 'aggregate_limit' => AGGREGATE_LIMIT],
    ]);
}

/** The administrator table only needs ids and counts; names come from members. */
function admin_post_rows(): array
{
    $posts = db_rows('SELECT id, author_id, body, created_at FROM posts ORDER BY created_at DESC LIMIT ' . PAGE_LIMIT);
    $ids = \array_map(static fn (array $row): string => (string) $row['id'], $posts);
    $media = $ids === [] ? [] : db_rows('SELECT id, post_id FROM media WHERE status = \'ready\' AND post_id IN ('
        . in_marks($ids) . ') LIMIT ' . AGGREGATE_LIMIT, $ids);
    $reactions = rows_by_ids('reactions', 'post_id, user_id, kind', 'post_id', $ids);
    $comment_rows = rows_by_ids('comments', 'id, post_id', 'post_id', $ids);

    $media_count = [];
    foreach ($media as $row) {
        $key = (string) $row['post_id'];
        $media_count[$key] = ($media_count[$key] ?? 0) + 1;
    }
    $reaction_count = [];
    foreach ($reactions as $row) {
        $key = (string) $row['post_id'];
        $reaction_count[$key] = ($reaction_count[$key] ?? 0) + 1;
    }
    $comment_count = [];
    foreach ($comment_rows as $row) {
        $key = (string) $row['post_id'];
        $comment_count[$key] = ($comment_count[$key] ?? 0) + 1;
    }

    return \array_map(static fn (array $row): array => [
        'id' => $row['id'],
        'author' => $row['author_id'],
        'text' => $row['body'],
        'time' => $row['created_at'],
        'media' => $media_count[(string) $row['id']] ?? 0,
        'reactions' => $reaction_count[(string) $row['id']] ?? 0,
        'comments' => $comment_count[(string) $row['id']] ?? 0,
    ], $posts);
}

function handle_admin_reset_password(string $target_id, array $admin): void
{
    if ($target_id === $admin['id']) {
        throw new AppError('use_settings_for_own_password', 400);
    }
    $body = read_json_body();
    $password = validate_password($body['password'] ?? null);
    $target = db_row('SELECT id, password_hash FROM users WHERE id = ? LIMIT 1', [$target_id]);
    if ($target === null) {
        send_error('not_found', 404);
        return;
    }
    $derived = hash_password($password);
    $updated = db_exec(
        'UPDATE users SET password_salt = ?, password_hash = ?, password_iterations = ? WHERE id = ? AND password_hash = ?',
        [$derived['salt'], $derived['hash'], $derived['iterations'], $target_id, $target['password_hash']]
    );
    if ($updated !== 1) {
        send_error('write_conflict', 409);
        return;
    }
    revoke_all_sessions($target_id);
    $row = db_row('SELECT ' . ACCOUNT_COLUMNS . ' FROM users WHERE id = ? LIMIT 1', [$target_id]);
    send_json(['ok' => true, 'member' => public_user($row ?? [])]);
}

function handle_admin_set_status(string $target_id, array $admin): void
{
    $body = read_json_body();
    $status = validate_status($body['status'] ?? null);
    if ($target_id === $admin['id'] && $status === 'suspended') {
        throw new AppError('cannot_suspend_self', 400);
    }
    $target = db_row('SELECT id, status FROM users WHERE id = ? LIMIT 1', [$target_id]);
    if ($target === null) {
        send_error('not_found', 404);
        return;
    }
    $updated = db_exec('UPDATE users SET status = ? WHERE id = ? AND status = ?', [$status, $target_id, $target['status']]);
    if ($updated !== 1) {
        send_error('write_conflict', 409);
        return;
    }
    if ($status === 'suspended') {
        revoke_all_sessions($target_id);
    }
    $row = db_row('SELECT ' . ACCOUNT_COLUMNS . ' FROM users WHERE id = ? LIMIT 1', [$target_id]);
    send_json(['ok' => true, 'member' => public_user($row ?? [])]);
}

function handle_admin_set_role(string $target_id, array $admin): void
{
    $body = read_json_body();
    $role = validate_role($body['role'] ?? null);
    if ($target_id === $admin['id']) {
        throw new AppError('cannot_change_own_role', 400);
    }
    $target = db_row('SELECT id, role FROM users WHERE id = ? LIMIT 1', [$target_id]);
    if ($target === null) {
        send_error('not_found', 404);
        return;
    }
    if ($target['role'] === 'admin' && $role !== 'admin') {
        // An administrator-less site could no longer moderate itself or lift its own
        // suspension, so the last one keeps the role until another is appointed.
        $admins = db_rows('SELECT id FROM users WHERE role = \'admin\' LIMIT ' . PAGE_LIMIT);
        if (\count($admins) === 1 && $admins[0]['id'] === $target_id) {
            throw new AppError('last_admin', 400);
        }
    }
    $updated = db_exec('UPDATE users SET role = ? WHERE id = ? AND role = ?', [$role, $target_id, $target['role']]);
    if ($updated !== 1) {
        send_error('write_conflict', 409);
        return;
    }
    $row = db_row('SELECT ' . ACCOUNT_COLUMNS . ' FROM users WHERE id = ? LIMIT 1', [$target_id]);
    send_json(['ok' => true, 'member' => public_user($row ?? [])]);
}

function handle_admin_delete_member(string $target_id, array $admin): void
{
    if ($target_id === $admin['id']) {
        throw new AppError('cannot_delete_self', 400);
    }
    $target = db_row('SELECT id, role FROM users WHERE id = ? LIMIT 1', [$target_id]);
    if ($target === null) {
        send_error('not_found', 404);
        return;
    }
    if ($target['role'] === 'admin') {
        throw new AppError('cannot_delete_admin', 400);
    }
    $objects = db_rows('SELECT id, object_path FROM media WHERE owner_id = ? LIMIT ' . AGGREGATE_LIMIT, [$target_id]);
    $deleted = db_transaction(static fn (): int => db_exec(
        // The cascade drops the member's posts, comments, reactions and media rows.
        'DELETE FROM users WHERE id = ? AND role = \'member\'',
        [$target_id]
    ));
    if ($deleted !== 1) {
        send_error('write_conflict', 409);
        return;
    }
    if ($objects !== []) {
        $paths = \array_map(static fn (array $row): string => (string) $row['object_path'], $objects);
        if (!storage_remove($paths)) {
            storage_remove($paths);
        }
    }
    send_json(['ok' => true, 'media_removed' => \count($objects)]);
}

function handle_admin_prune(): void
{
    $members = db_rows('SELECT id, avatar_media_id, cover_media_id FROM users LIMIT ' . PAGE_LIMIT);
    $media = db_rows('SELECT id, owner_id, object_path, status, size, created_at, post_id FROM media'
        . ' ORDER BY created_at LIMIT ' . AGGREGATE_LIMIT);
    $live = [];
    foreach ($members as $row) {
        if ($row['avatar_media_id']) {
            $live[] = $row['avatar_media_id'];
        }
        if ($row['cover_media_id']) {
            $live[] = $row['cover_media_id'];
        }
    }
    $now = now_ms();
    $stale = [];
    foreach ($media as $row) {
        if (\in_array($row['id'], $live, true)) {
            continue;
        }
        $created = iso_to_ms($row['created_at']);
        if ($row['status'] === 'pending') {
            if ($created !== null && $now - $created > PRUNE_GRACE_MS) {
                $stale[] = $row;
            }
            continue;
        }
        if ($row['post_id'] === null) {
            $stale[] = $row;
        }
    }
    if ($stale === []) {
        send_json(['ok' => true, 'removed' => 0, 'bytes' => 0]);
        return;
    }
    $stale_ids = \array_map(static fn (array $row): string => (string) $row['id'], $stale);
    $bytes = 0;
    foreach ($stale as $row) {
        if (\is_int($row['size'])) {
            $bytes += $row['size'];
        }
    }
    db_exec('DELETE FROM media WHERE id IN (' . in_marks($stale_ids) . ')', $stale_ids);
    $paths = \array_map(static fn (array $row): string => (string) $row['object_path'], $stale);
    $objects_cleaned = storage_remove($paths) || storage_remove($paths);
    send_json([
        'ok' => true,
        'removed' => \count($stale),
        'bytes' => $bytes,
        'objects_cleaned' => $objects_cleaned,
    ]);
}

function handle_admin_export(): void
{
    send_json([
        'exported_at' => now_iso(),
        'truncated' => db_count('users') >= AGGREGATE_LIMIT || db_count('posts') >= AGGREGATE_LIMIT
            || db_count('media') >= AGGREGATE_LIMIT || db_count('comments') >= AGGREGATE_LIMIT
            || db_count('reactions') >= AGGREGATE_LIMIT,
        'counts' => [
            'users' => \min(db_count('users'), AGGREGATE_LIMIT),
            'posts' => \min(db_count('posts'), AGGREGATE_LIMIT),
            'media' => \min(db_count('media'), AGGREGATE_LIMIT),
            'comments' => \min(db_count('comments'), AGGREGATE_LIMIT),
            'reactions' => \min(db_count('reactions'), AGGREGATE_LIMIT),
        ],
        'users' => db_rows('SELECT id, email, name, handle, bio, role, status, created_at, last_login_at, login_count'
            . ' FROM users ORDER BY created_at LIMIT ' . AGGREGATE_LIMIT),
        'posts' => db_rows('SELECT id, author_id, body, created_at FROM posts'
            . ' ORDER BY created_at DESC LIMIT ' . AGGREGATE_LIMIT),
        'media' => db_rows('SELECT id, owner_id, post_id, kind, content_type, size, status, created_at FROM media'
            . ' ORDER BY created_at LIMIT ' . AGGREGATE_LIMIT),
        'comments' => db_rows('SELECT id, post_id, author_id, body, created_at FROM comments'
            . ' ORDER BY created_at LIMIT ' . AGGREGATE_LIMIT),
        'reactions' => db_rows('SELECT post_id, user_id, kind, created_at FROM reactions LIMIT ' . AGGREGATE_LIMIT),
    ], 200, ['content-disposition: attachment; filename="loopr-export.json"']);
}

// ---- routing -------------------------------------------------------------

function route_request(): void
{
    require_trusted_origin();
    $path = application_path();
    $method = method();

    if ($path === '/api/health' && $method === 'GET') {
        send_json(['ok' => true]);
        return;
    }
    if ($path === '/api/register' && $method === 'POST') {
        handle_register();
        return;
    }
    if ($path === '/api/login' && $method === 'POST') {
        handle_login();
        return;
    }
    if ($path === '/api/logout' && $method === 'POST') {
        handle_logout();
        return;
    }

    $upload = \preg_match('#^/api/storage/(upload|object)/([A-Za-z0-9._-]{16,256})$#', $path, $ticket) === 1;
    if ($upload) {
        if ($ticket[1] === 'upload' && $method === 'PUT') {
            handle_storage_upload($ticket[2]);
            return;
        }
        if ($ticket[1] === 'object' && ($method === 'GET' || $method === 'HEAD')) {
            handle_storage_read($ticket[2]);
            return;
        }
        throw new AppError('method_not_allowed', 405);
    }

    ['user' => $user] = current_account();

    if ($path === '/api/state' && $method === 'GET') {
        handle_state($user);
        return;
    }
    if ($path === '/api/session' && $method === 'GET') {
        send_json(['user' => \array_merge(public_user($user), ['email' => $user['email']])]);
        return;
    }
    // Only the aggregates, so the client can re-sync its counters after a write
    // without re-downloading the feed.
    if ($path === '/api/me/stats' && $method === 'GET') {
        send_json(['stats' => personal_stats((string) $user['id'])]);
        return;
    }

    if ($path === '/api/me' && $method === 'PATCH') {
        handle_edit_profile($user);
        return;
    }
    if ($path === '/api/me/password' && $method === 'POST') {
        handle_change_password($user);
        return;
    }
    if ($path === '/api/me/avatar' && $method === 'DELETE') {
        handle_remove_profile_media($user, 'avatar');
        return;
    }
    if ($path === '/api/me/cover' && $method === 'DELETE') {
        handle_remove_profile_media($user, 'cover');
        return;
    }

    if ($path === '/api/uploads' && $method === 'POST') {
        handle_upload_intent($user);
        return;
    }
    if (\preg_match('#^/api/uploads/([0-9a-f-]{36})/complete$#', $path, $one) === 1
        && is_uuid($one[1]) && $method === 'POST') {
        handle_complete_upload($user, $one[1]);
        return;
    }
    if (\preg_match('#^/api/uploads/([0-9a-f-]{36})/apply$#', $path, $two) === 1
        && is_uuid($two[1]) && $method === 'POST') {
        handle_apply_upload($user, $two[1]);
        return;
    }

    if (\preg_match('#^/api/users/([0-9a-f-]{36})/stats$#', $path, $three) === 1
        && is_uuid($three[1]) && $method === 'GET') {
        handle_user_stats($three[1]);
        return;
    }

    if ($path === '/api/posts' && $method === 'POST') {
        handle_create_post($user);
        return;
    }
    if (\preg_match('#^/api/posts/([0-9a-f-]{36})(/(reaction|comments|media))?$#', $path, $four) === 1
        && is_uuid($four[1])) {
        $sub = $four[3] ?? '';
        if ($sub === '' && $method === 'DELETE') {
            handle_delete_post($user, $four[1]);
            return;
        }
        if ($sub === 'reaction' && $method === 'PUT') {
            handle_set_reaction($user, $four[1]);
            return;
        }
        if ($sub === 'comments' && $method === 'POST') {
            handle_add_comment($user, $four[1]);
            return;
        }
        if ($sub === 'media' && $method === 'POST') {
            handle_attach_media($user, $four[1]);
            return;
        }
    }
    if (\preg_match('#^/api/comments/([0-9a-f-]{36})$#', $path, $five) === 1
        && is_uuid($five[1]) && $method === 'DELETE') {
        handle_delete_comment($user, $five[1]);
        return;
    }

    if (\preg_match('#^/api/media/([0-9a-f-]{36})/(data|url)$#', $path, $six) === 1
        && is_uuid($six[1]) && $method === 'GET') {
        if ($six[2] === 'data') {
            handle_media_data($six[1]);
        } else {
            handle_media_url($six[1]);
        }
        return;
    }

    if (\str_starts_with($path, '/api/admin/')) {
        if ($user['role'] !== 'admin') {
            throw new AppError('forbidden', 403);
        }
        if ($path === '/api/admin/overview' && $method === 'GET') {
            handle_admin_overview();
            return;
        }
        if ($path === '/api/admin/export' && $method === 'GET') {
            handle_admin_export();
            return;
        }
        if ($path === '/api/admin/prune' && $method === 'POST') {
            handle_admin_prune();
            return;
        }
        if (\preg_match('#^/api/admin/members/([0-9a-f-]{36})(/(password|status|role))?$#', $path, $seven) === 1
            && is_uuid($seven[1])) {
            $action = $seven[3] ?? '';
            if ($action === '' && $method === 'DELETE') {
                handle_admin_delete_member($seven[1], $user);
                return;
            }
            if ($action === 'password' && $method === 'POST') {
                handle_admin_reset_password($seven[1], $user);
                return;
            }
            if ($action === 'status' && $method === 'POST') {
                handle_admin_set_status($seven[1], $user);
                return;
            }
            if ($action === 'role' && $method === 'POST') {
                handle_admin_set_role($seven[1], $user);
                return;
            }
        }
    }

    if (\in_array($method, ['POST', 'PATCH', 'PUT', 'DELETE'], true)) {
        throw new AppError('method_not_allowed', 405);
    }
    throw new AppError('not_found', 404);
}
