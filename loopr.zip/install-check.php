<?php

/**
 * Dev/hosting helper, not part of the app: run it once on the host to see whether
 * this PHP + SQLite backend can start here. It prints no paths, no secrets and no
 * rows, only readiness. Delete it as soon as it says ok.
 */

declare(strict_types=1);

header('content-type: text/plain; charset=utf-8');
header('cache-control: no-store');
header('x-content-type-options: nosniff');

// Exactly what this backend calls: PDO's SQLite driver, hash_pbkdf2/hash_hmac, json
// and the mbstring name limits. openssl, curl and fileinfo are never touched.
$requirements = ['pdo_sqlite', 'hash', 'json', 'mbstring'];
$lines = [];
$ok = true;

$lines[] = 'php ' . PHP_VERSION;
foreach ($requirements as $name) {
    $present = \extension_loaded($name);
    $ok = $ok && $present;
    $lines[] = \sprintf('%-12s %s', $name, $present ? 'ok' : 'MISSING');
}

$hash = \function_exists('hash_pbkdf2') ? \strlen(\hash_pbkdf2('sha256', 'a', 'b', 1000, 32, true)) : 0;
$ok = $ok && $hash === 32;
$lines[] = 'pbkdf2-sha256(32 bytes) ' . ($hash === 32 ? 'ok' : 'MISSING');

try {
    require __DIR__ . '/loopr/config.php';
    require __DIR__ . '/loopr/http.php';
    require __DIR__ . '/loopr/clock.php';
    require __DIR__ . '/loopr/db.php';
    if (!\is_dir(\Loopr\DATA_DIR)) {
        @\mkdir(\Loopr\DATA_DIR, 0771, true);
    }
    $writable = \is_writable(\Loopr\DATA_DIR);
    $ok = $ok && $writable;
    $lines[] = 'data directory ' . ($writable ? 'ok' : 'NOT WRITABLE');
    $count = $writable ? \Loopr\db_count('users') : -1;
    $ok = $ok && $count >= 0;
    $lines[] = 'sqlite schema ' . ($count >= 0 ? 'ok' : 'FAILED');
    $lines[] = 'accounts already here ' . \max($count, 0);
} catch (\Throwable $error) {
    $ok = false;
    $lines[] = 'database FAILED (' . $error::class . ')';
}

$lines[] = $ok ? 'READY - delete this file now' : 'NOT READY - see the lines above';
echo \implode("\n", $lines), "\n";
