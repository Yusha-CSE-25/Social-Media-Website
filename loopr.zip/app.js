/* Loopr — a hosted social network. Accounts, posts, reactions, replies and
   uploaded files live on the site's own backend; this file renders what the API
   returns and sends every visitor action back to it. */
(() => {
'use strict';

const API = window.LooprAPI;

/* ============================================================
   1. STATE
   ============================================================ */
const DB = {
  status: 'booting',            // booting | ready | offline
  error: '',
  me: null,
  users: [],
  posts: [],
  media: {},                    // id -> { id, owner, post, kind, type, size }
  limits: {},
  admin: null,
  member: null,                 // { id, view | error }
  videoUrls: {},                // id -> { url, expires }
};

const UI = { view:'feed', filter:'all', sort:'new', query:'', profileId:null, profileTab:'posts', pickerFor:null, drafts:[] };

const REACTIONS = [
  { key:'like', emoji:'👍', label:'Like' },
  { key:'love', emoji:'❤️', label:'Love' },
  { key:'wow',  emoji:'😮', label:'Wow' },
  { key:'haha', emoji:'😂', label:'Haha' },
  { key:'sad',  emoji:'😢', label:'Sad' },
  { key:'mew',  emoji:'🐱', label:'Mew' },
];
const REACT = Object.fromEntries(REACTIONS.map(r => [r.key, r]));

/* ============================================================
   2. SMALL HELPERS
   ============================================================ */
const $  = (sel, root = document) => root.querySelector(sel);
const $$ = (sel, root = document) => [...root.querySelectorAll(sel)];

/* Sent as the idempotency key of a single intent; never a secret. */
const uuid = () => (crypto.randomUUID
  ? crypto.randomUUID()
  : 'xxxxxxxx-xxxx-4xxx-yxxx-xxxxxxxxxxxx'.replace(/[xy]/g, (c) => {
      const r = Math.random() * 16 | 0;
      return (c === 'x' ? r : (r & 0x3 | 0x8)).toString(16);
    }));

const esc = (s = '') => String(s).replace(/[&<>"']/g, c => ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));

function linkify(safe){
  return safe
    .replace(/(https?:\/\/[^\s<]+)/g, '<a href="$1" target="_blank" rel="noopener noreferrer">$1</a>')
    .replace(/(^|\s)#([\p{L}\p{N}_]{2,30})/gu, '$1<span class="tag">#$2</span>');
}
const richText = raw => linkify(esc(raw));

const at = value => (typeof value === 'string' ? Date.parse(value) : Number(value) || 0);

function timeAgo(value){
  const then = at(value);
  if (!then) return 'unknown time';
  const d = Math.floor((Date.now() - then) / 1000);
  if (d < 60) return 'just now';
  if (d < 3600) return Math.floor(d / 60) + 'm ago';
  if (d < 86400) return Math.floor(d / 3600) + 'h ago';
  if (d < 604800) return Math.floor(d / 86400) + 'd ago';
  return new Date(then).toLocaleDateString();
}
function formatBytes(b){
  const n = Number(b) || 0;
  if (n < 1024) return n + ' B';
  if (n < 1048576) return (n / 1024).toFixed(1) + ' KB';
  return (n / 1048576).toFixed(2) + ' MB';
}
function toast(msg, kind = ''){
  const t = document.createElement('div');
  t.className = 'toast ' + kind;
  t.textContent = msg;
  $('#toasts').appendChild(t);
  setTimeout(() => { t.style.opacity = '0'; t.style.transition = 'opacity .25s'; setTimeout(() => t.remove(), 260); }, 3600);
}

function userById(id){
  if (!id) return null;
  return DB.users.find(u => u.id === id)
    || ((DB.admin && DB.admin.members) || []).find(u => u.id === id)
    || (DB.member && DB.member.view && DB.member.view.profile.id === id ? DB.member.view.profile : null)
    || null;
}
const displayName = user => (user ? user.name : 'Former member');
const initials = name => (name || '?').trim().split(/\s+/).slice(0, 2).map(w => w[0]).join('').toUpperCase();

/* Pictures are served through the application's media endpoint, so the visitor's
   own session decides whether the stored bytes come back. */
const pictureUrl = mediaId => (mediaId ? API.mediaDataUrl(mediaId) : '');

function avatarNode(user, cls = ''){
  const src = user && pictureUrl(user.avatar_media_id);
  return `<span class="avatar ${cls}" ${src ? `style="background-image:url('${src}')"` : ''}>${src ? '' : esc(initials(user && user.name))}</span>`;
}

const reactionCount = post => Object.keys(post.reactions || {}).length;
const myReaction = (post, userId) => (post.reactions || {})[userId] || null;

function reactionTally(post){
  const tally = {};
  for (const key of Object.values(post.reactions || {})) tally[key] = (tally[key] || 0) + 1;
  return Object.entries(tally).sort((a, b) => b[1] - a[1] || a[0].localeCompare(b[0]));
}

function reactionsHtml(post, me){
  const tally = reactionTally(post);
  if (!tally.length) return '';
  const total = reactionCount(post);
  const mine = me && myReaction(post, me.id);
  const others = total - (mine ? 1 : 0);
  const label = mine
    ? `${REACT[mine].label}${others > 0 ? ` · ${others} other${others > 1 ? 's' : ''}` : ''}`
    : `${total} reaction${total > 1 ? 's' : ''}`;
  const names = Object.entries(post.reactions).slice(0, 12)
    .map(([id, k]) => `${displayName(userById(id))} → ${REACT[k] ? REACT[k].label : k}`);
  return `<div class="reactions" title="${esc(names.join('\n'))}">
    <span class="rsum">${tally.slice(0, 3).map(([k]) => `<i>${REACT[k].emoji}</i>`).join('')}</span>
    <span class="muted small">${esc(label)}</span>
  </div>`;
}

function pickerHtml(post, me){
  const mine = me && myReaction(post, me.id);
  return `<div class="react-picker">${REACTIONS.map(r =>
    `<button type="button" class="rp ${mine === r.key ? 'on' : ''}" data-act="react-set" data-id="${post.id}" data-key="${r.key}" title="${r.label}">
       <span class="e">${r.emoji}</span><em>${r.label}</em>
     </button>`).join('')}</div>`;
}

/* ---------- statistics helpers (pure CSS charts, no libraries) ---------- */
function chartHtml(series){
  if (!series || !series.length) return '';
  const max = Math.max(1, ...series.map(s => s.n));
  return series.map(s =>
    `<div class="bar ${s.n ? '' : 'zero'}" style="height:${s.n ? Math.max(8, s.n / max * 100).toFixed(1) : 3}%" title="${esc(s.label)} — ${s.n} post${s.n === 1 ? '' : 's'}"></div>`
  ).join('');
}
function mixRows(entries, total, labelFn){
  if (!entries.length) return '<li class="muted small">No data yet.</li>';
  const max = Math.max(1, ...entries.map(e => e[1]));
  return entries.map(([k, n]) => `<li>
      <span class="e">${esc(labelFn(k))}</span>
      <span class="track"><i class="fill" style="width:${(n / max * 100).toFixed(1)}%"></i></span>
      <span class="n">${n > 1024 ? formatBytes(n) : n}</span><span class="pct">${total ? Math.round(n / total * 100) : 0}%</span>
    </li>`).join('');
}
const mixEntries = mix => Object.entries(mix || {}).map(([k, v]) => [k, Number(v) || 0]).sort((a, b) => b[1] - a[1]);
function statsList(items){
  return items.map(([label, value]) => `<li><b>${esc(value)}</b><span>${esc(label)}</span></li>`).join('');
}
const statOf = (stats, key) => Number((stats && stats[key]) || 0);

/* ============================================================
   3. RENDERING — POST CARD
   ============================================================ */
function mediaHtml(ids){
  if (!ids || !ids.length) return '';
  const cells = ids.map(id => {
    const m = DB.media[id];
    if (!m) return '<div class="empty small">attachment no longer stored</div>';
    if (m.kind === 'video') return `<video data-media="${id}" controls preload="metadata"></video>`;
    const src = API.mediaDataUrl(id);
    return `<img src="${src}" alt="${esc(m.type || 'attachment')}" data-lightbox="${src}" loading="lazy" />`;
  }).join('');
  return `<div class="post-media ${ids.length === 1 ? 'one' : ''}">${cells}</div>`;
}

function commentsHtml(post, me){
  const list = (post.comments || []).map(c => {
    const author = userById(c.author);
    const canDrop = me && (me.role === 'admin' || me.id === c.author);
    return `<div class="comment">${avatarNode(author, 'sm')}
      <div class="body"><b>${esc(displayName(author))}</b>
      <p>${richText(c.text)} <span class="muted small">· ${timeAgo(c.time)}</span></p></div>
      ${canDrop ? `<button class="act" data-act="drop-comment" data-id="${post.id}" data-cid="${c.id}">×</button>` : ''}
    </div>`;
  }).join('');
  const max = DB.limits.comment_max_chars || 500;
  return `<div class="comments" data-comments-for="${post.id}">
      ${list || '<p class="muted small" style="margin:0">No replies yet.</p>'}
      <form data-comment-form="${post.id}"><input placeholder="Write a reply…" maxlength="${max}" required />
      <button class="btn small" type="submit">Reply</button></form>
    </div>`;
}

function postCard(post, me, opts = {}){
  const author = userById(post.author);
  const mine = me && myReaction(post, me.id);
  const total = reactionCount(post);
  const canDelete = me && (me.role === 'admin' || me.id === post.author);
  return `<article class="post" data-post="${post.id}">
    <div class="post-head">
      <button class="act" style="padding:0" data-act="open-profile" data-uid="${esc(post.author)}" title="View profile">
        ${avatarNode(author, 'lg')}
      </button>
      <div class="who">
        <button class="n" data-act="open-profile" data-uid="${esc(post.author)}">${esc(displayName(author))}</button>
        <span class="t">${timeAgo(post.time)}${author ? ' · @' + esc(author.handle) : ''}</span>
      </div>
      ${author && author.role === 'admin' ? '<span class="role">admin</span>' : ''}
    </div>
    ${post.text ? `<p class="post-text">${richText(post.text)}</p>` : ''}
    ${mediaHtml(post.media)}
    ${reactionsHtml(post, me)}
    <div class="post-actions">
      <div class="react-group" data-picker-anchor="${post.id}">
        ${UI.pickerFor === post.id ? pickerHtml(post, me) : ''}
        <button class="act ${mine ? 'on r-' + mine : ''}" data-act="react" data-id="${post.id}">
          ${mine ? REACT[mine].emoji : '👍'} ${mine ? REACT[mine].label : 'React'}${total ? ` <b>${total}</b>` : ''}
        </button>
        <button class="act caret" data-act="picker" data-id="${post.id}" title="Choose a reaction">⌄</button>
      </div>
      <button class="act" data-act="toggle-comments" data-id="${post.id}">💬 ${(post.comments || []).length}</button>
      <button class="act" data-act="share" data-id="${post.id}">↗ Copy text</button>
      ${canDelete ? `<button class="act" data-act="delete" data-id="${post.id}">🗑 Delete</button>` : ''}
    </div>
    ${opts.showComments ? commentsHtml(post, me) : ''}
  </article>`;
}

/* Video plays through a short-lived signed link, fetched once per stored file. */
async function hydrateVideos(){
  const ids = [...new Set($$('video[data-media]').filter(v => !v.src).map(v => v.dataset.media))];
  for (const id of ids){
    const cached = DB.videoUrls[id];
    try {
      let url = cached && cached.expires > Date.now() ? cached.url : null;
      if (!url){
        const result = await API.mediaSignedUrl(id);
        url = result.signedUrl;
        DB.videoUrls[id] = { url, expires: Date.now() + 45 * 60 * 1000 };
      }
      $$(`video[data-media="${id}"]`).forEach(v => { if (!v.src) v.src = url; });
    } catch {
      $$(`video[data-media="${id}"]`).forEach(v => v.remove());
    }
  }
}

/* ============================================================
   4. RENDERING — FEED
   ============================================================ */
function visiblePosts(me){
  let list = DB.posts.slice();
  const q = UI.query.trim().toLowerCase();
  if (UI.filter === 'mine')  list = list.filter(p => p.author === me.id);
  if (UI.filter === 'media') list = list.filter(p => (p.media || []).length);
  if (UI.filter === 'reacted') list = list.filter(p => myReaction(p, me.id));
  if (q) list = list.filter(p => {
    const a = userById(p.author);
    return (p.text || '').toLowerCase().includes(q) || (a && (a.name + ' ' + a.handle).toLowerCase().includes(q));
  });
  if (UI.sort === 'old') list.sort((a, b) => at(a.time) - at(b.time));
  else if (UI.sort === 'top') list.sort((a, b) => reactionCount(b) - reactionCount(a));
  else list.sort((a, b) => at(b.time) - at(a.time));
  return list;
}

const openComments = new Set();

function renderFeed(me){
  const list = visiblePosts(me);
  $('#feed').innerHTML = list.map(p => postCard(p, me, { showComments: openComments.has(p.id) })).join('');
  const empty = $('#feed-empty');
  empty.hidden = DB.status !== 'ready' || list.length > 0;
  if (UI.query) empty.textContent = `No posts match “${UI.query}”.`;
  else if (DB.posts.length) empty.textContent = 'No posts match this filter.';
  else empty.textContent = 'Nothing here yet. Write the first post.';
  const note = $('#feed-note');
  note.hidden = DB.status !== 'ready' || DB.posts.length < (DB.limits.feed_limit || 100);
  note.textContent = `The feed holds the ${DB.posts.length} newest posts on the site.`;
}

/* ============================================================
   5. RENDERING — PROFILE
   ============================================================ */
let memberInFlight = false;

function ensureMember(id){
  if (memberInFlight || (DB.member && DB.member.id === id)) return;
  memberInFlight = true;
  API.memberView(id)
    .then(view => {
      DB.member = { id, view };
      for (const m of view.media) DB.media[m.id] = m;
    })
    .catch(err => { DB.member = { id, error: API.copyFor(err) }; })
    .finally(() => { memberInFlight = false; render(); });
}

function renderProfile(me){
  const id = UI.profileId || me.id;
  const loaded = DB.member && DB.member.id === id ? DB.member : null;
  const view = loaded && loaded.view;
  const user = (view && view.profile) || userById(id) || me;
  const isMe = user.id === me.id;
  const stats = (view && view.stats) || me.stats || {};

  $('#profile-cover').style.backgroundImage = user.cover_media_id ? `url('${pictureUrl(user.cover_media_id)}')` : '';
  const box = $('#profile-avatar-box');
  const avatar = pictureUrl(user.avatar_media_id);
  box.style.backgroundImage = avatar ? `url('${avatar}')` : '';
  box.textContent = avatar ? '' : initials(user.name);

  $('#profile-name').textContent = displayName(user);
  $('#profile-role').hidden = user.role !== 'admin';
  $('#profile-handle').textContent = '@' + (user.handle || 'unknown');
  $('#profile-bio').textContent = user.bio || (isMe ? 'Add a short bio so people know who you are.' : 'No bio yet.');
  const joined = user.joined ? new Date(at(user.joined)).toLocaleDateString() : 'unknown';
  const lastSeen = view ? view.last_login_at : me.last_login_at;
  $('#profile-since').textContent = `Joined ${joined} · last sign-in ${lastSeen ? timeAgo(lastSeen) : 'not yet recorded'}`;

  $('#profile-stats').innerHTML = [
    ['Posts', statOf(stats, 'posts')],
    ['Photos & video', statOf(stats, 'media')],
    ['Reactions', statOf(stats, 'reactions_received')],
    ['Replies', statOf(stats, 'comments_given')],
  ].map(([label, n]) => `<li><b>${n}</b><span>${label}</span></li>`).join('');

  const ownPosts = view ? view.posts : DB.posts.filter(p => p.author === id);
  const received = statOf(stats, 'reactions_received');
  const best = ownPosts.reduce((n, p) => Math.max(n, reactionCount(p)), 0);
  $('#profile-analytics').innerHTML = statsList([
    ['Reactions', received],
    ['Per post', statOf(stats, 'posts') ? (received / statOf(stats, 'posts')).toFixed(1) : '0.0'],
    ['Given', statOf(stats, 'reactions_given')],
    ['Replies in', statOf(stats, 'comments_received')],
    ['Replies out', statOf(stats, 'comments_given')],
    ['Best loaded post', best],
    ['Files', statOf(stats, 'media')],
    ['Storage', formatBytes(statOf(stats, 'bytes'))],
    ['Sign-ins', view ? view.login_count : (me.login_count || 0)],
  ]);
  $('#profile-mix').innerHTML = view || isMe
    ? mixRows(mixEntries(stats.mix), received, k => REACT[k] ? `${REACT[k].emoji} ${REACT[k].label}` : k)
    : '<li class="muted small">Loading…</li>';
  $('#profile-chart').innerHTML = view ? chartHtml(view.history) : '';

  $('#hero-actions').hidden = !isMe;
  $('#quick-avatar-btn').hidden = !isMe;

  $$('#profile-tabs .chip').forEach(c => c.classList.toggle('active', c.dataset.tab === UI.profileTab));
  const reacted = DB.posts.filter(p => myReaction(p, id)).sort((a, b) => at(b.time) - at(a.time));
  const withMedia = ownPosts.filter(p => (p.media || []).length);
  const source = UI.profileTab === 'media' ? withMedia : UI.profileTab === 'reacted' ? reacted : ownPosts;
  const emptyMessage = {
    posts:'No posts yet.',
    media:'No photos or video posted yet.',
    reacted:'No reactions given among the loaded posts yet.',
  }[UI.profileTab];
  if (loaded && loaded.error) $('#profile-list').innerHTML = `<p class="empty">${esc(loaded.error)}</p>`;
  else {
    $('#profile-list').innerHTML = source.map(p => postCard(p, me, { showComments: openComments.has(p.id) })).join('')
      || `<p class="empty">${emptyMessage}</p>`;
    if (view && view.posts_truncated && source.length){
      $('#profile-list').insertAdjacentHTML('beforeend', '<p class="muted small">This member has more posts than the ones listed above.</p>');
    }
  }

  const form = $('#profile-edit');
  form.hidden = !isMe;
  if (isMe){
    form.name.value = user.name || '';
    form.bio.value = user.bio || '';
    $('#profile-edit-title').textContent = 'Edit your profile';
  }
}

/* ============================================================
   6. RENDERING — ADMIN
   ============================================================ */
let adminInFlight = false;

function ensureAdmin(){
  if (adminInFlight || DB.admin) return;
  adminInFlight = true;
  API.adminOverview()
    .then(overview => { DB.admin = overview; })
    .catch(err => { DB.admin = { error: API.copyFor(err) }; })
    .finally(() => { adminInFlight = false; render(); });
}

function renderAdmin(me){
  const board = $('#admin-loading');
  if (!DB.admin){ board.hidden = false; board.textContent = 'Loading site statistics…'; return; }
  if (DB.admin.error){ board.hidden = false; board.textContent = DB.admin.error; return; }
  board.hidden = true;

  const site = DB.admin.site;
  const members = DB.admin.members || [];
  const posts = DB.admin.posts || [];

  $$('[data-admin]').forEach(el => {
    const k = el.dataset.admin;
    el.textContent = k === 'users' ? site.users
      : k === 'posts' ? site.posts
      : k === 'media' ? site.media
      : formatBytes(site.bytes);
  });
  $$('[data-storage-label]').forEach(el => el.textContent =
    `${formatBytes(site.bytes)} of files · ${site.media} stored objects · ${site.comments} replies · ${site.reactions} reactions`);
  const truncated = $('#admin-truncated');
  truncated.hidden = !site.truncated;
  truncated.textContent = 'Some aggregates cover only the most recent records.';

  const mq = $('#member-search').value.trim().toLowerCase();
  const adminCount = members.filter(u => u.role === 'admin').length;
  $('#members-body').innerHTML = members
    .filter(u => !mq || (u.name + ' ' + u.email + ' ' + u.handle).toLowerCase().includes(mq))
    .map(u => {
      const self = u.id === me.id;
      const lastAdmin = u.role === 'admin' && adminCount <= 1;
      const roleBlocked = self ? 'Use another admin account to change your own role'
        : lastAdmin ? 'This site needs at least one administrator' : '';
      return `<tr>
        <td>${esc(u.name)}${self ? ' <span class="muted small">(you)</span>' : ''}</td>
        <td class="clip">${esc(u.email)}</td>
        <td><span class="pill ${u.role}">${u.role}</span></td>
        <td><span class="pill ${u.status}">${u.status}</span></td>
        <td>${u.posts_recent}</td>
        <td>
          <button class="btn small" data-act="a-role" data-uid="${u.id}" ${roleBlocked ? `disabled title="${esc(roleBlocked)}"` : ''}>${u.role === 'admin' ? 'Demote' : 'Make admin'}</button>
          <button class="btn small" data-act="a-status" data-uid="${u.id}" ${self ? 'disabled title="You cannot suspend your own account"' : ''}>${u.status === 'active' ? 'Suspend' : 'Activate'}</button>
          <button class="btn small danger-btn" data-act="a-del-user" data-uid="${u.id}" ${u.role === 'admin' ? 'disabled title="Administrators are removed by another administrator"' : ''}>Delete</button>
        </td></tr>`;
    }).join('') || '<tr><td colspan="6" class="muted">No members match.</td></tr>';

  const pq = $('#post-search').value.trim().toLowerCase();
  $('#posts-body').innerHTML = posts
    .filter(p => { const a = userById(p.author); return !pq || ((p.text || '') + ' ' + (a ? a.name + ' ' + a.handle : '')).toLowerCase().includes(pq); })
    .map(p => {
      const a = userById(p.author);
      return `<tr>
        <td>${esc(displayName(a))}</td>
        <td class="clip" title="${esc(p.text)}">${esc((p.text || '').slice(0, 90)) || '<span class="muted">(media only)</span>'}</td>
        <td>${p.media}</td>
        <td>${p.reactions}</td>
        <td>${timeAgo(p.time)}</td>
        <td><button class="btn small danger-btn" data-act="a-del-post" data-id="${p.id}">Delete</button></td>
      </tr>`;
    }).join('') || '<tr><td colspan="6" class="muted">No posts stored.</td></tr>';

  const series = site.history || [];
  const busiest = series.reduce((a, b) => (b.n > a.n ? b : a), series[0] || { label:'—', n:0 });
  const posted14 = series.reduce((n, s) => n + s.n, 0);
  $('#chart-posts').innerHTML = chartHtml(series);
  $('#chart-posts-label').textContent =
    `${posted14} post${posted14 === 1 ? '' : 's'} in the last 14 days · busiest day ${busiest.label} (${busiest.n})`;

  $('#chart-mix').innerHTML = mixRows(mixEntries(site.mix), site.reactions, k => REACT[k] ? `${REACT[k].emoji} ${REACT[k].label}` : k);

  const byOwner = members.map(u => [u.name, u.bytes]).filter(([, n]) => n > 0).sort((a, b) => b[1] - a[1]).slice(0, 8);
  $('#chart-storage').innerHTML = mixRows(byOwner, site.bytes, label => label);

  const dayAgo = Date.now() - 86400000;
  $('#site-analytics').innerHTML = statsList([
    ['Members', site.users],
    ['Admins', members.filter(u => u.role === 'admin').length],
    ['Posts', site.posts],
    ['Replies', site.comments],
    ['Reactions', site.reactions],
    ['Per post', site.posts ? (site.reactions / site.posts).toFixed(1) : '0.0'],
    ['Files', site.media],
    ['Storage', formatBytes(site.bytes)],
    ['Posted in 24h', new Set(posts.filter(p => at(p.time) > dayAgo).map(p => p.author)).size],
    ['Suspended', members.filter(u => u.status === 'suspended').length],
  ]);

  $('#top-body').innerHTML = members
    .slice()
    .sort((a, b) => b.reactions_recent - a.reactions_recent || b.posts_recent - a.posts_recent)
    .slice(0, 10)
    .map((u, i) => `<tr>
      <td>${i + 1}</td>
      <td>${esc(u.name)}</td>
      <td>${u.posts_recent}</td>
      <td>${u.reactions_recent}</td>
      <td>${formatBytes(u.bytes)}</td>
      <td>${u.last_login_at ? timeAgo(u.last_login_at) : 'no sign-in'}</td>
    </tr>`).join('') || '<tr><td colspan="6" class="muted">No members.</td></tr>';

  $('#reset-user').innerHTML = members
    .filter(u => u.id !== me.id)
    .map(u => `<option value="${u.id}">${esc(u.name)} · ${esc(u.email)}</option>`).join('')
    || '<option value="">No other members yet</option>';
}

/* ============================================================
   7. CHROME (header, sidebar)
   ============================================================ */
function renderChrome(me){
  const avatar = pictureUrl(me.avatar_media_id);
  $$('[data-avatar]').forEach(el => {
    el.style.backgroundImage = avatar ? `url('${avatar}')` : '';
    el.textContent = avatar ? '' : initials(me.name);
  });
  $$('[data-name]').forEach(el => el.textContent = me.name);
  $$('[data-handle]').forEach(el => el.textContent = '@' + me.handle);

  const stats = me.stats || {};
  $('[data-stat="posts"]').textContent = statOf(stats, 'posts');
  $('[data-stat="reactions"]').textContent = statOf(stats, 'reactions_received');
  $('[data-stat="media"]').textContent = statOf(stats, 'media');

  $('#people').innerHTML = DB.users
    .filter(u => u.id !== me.id && u.status === 'active')
    .slice(0, 12)
    .map(u => `<li><button data-act="open-profile" data-uid="${u.id}">${avatarNode(u)}<span class="n">${esc(u.name)}</span></button></li>`)
    .join('') || '<li class="muted small">No other members yet — invite someone to register.</li>';

  $$('.admin-only').forEach(el => el.hidden = me.role !== 'admin');

  $('#sidebar-storage').innerHTML = [
    [DB.posts.length, 'loaded posts'],
    [statOf(stats, 'media'), 'my files'],
    [formatBytes(statOf(stats, 'bytes')), 'my storage'],
    [(DB.admin && DB.admin.site) ? DB.admin.site.users : DB.users.length, 'members'],
  ].map(([n, label]) => `<li><b>${esc(n)}</b><span>${esc(label)}</span></li>`).join('');
}

/* ============================================================
   7b. RENDERING — SETTINGS
   ============================================================ */
function renderSettings(me){
  const av = $('#set-avatar');
  const avatar = pictureUrl(me.avatar_media_id);
  av.style.backgroundImage = avatar ? `url('${avatar}')` : '';
  av.textContent = avatar ? '' : initials(me.name);
  const avatarRow = avatar ? DB.media[me.avatar_media_id] : null;
  $('#set-avatar-name').textContent = avatar
    ? `Picture stored on the site · ${formatBytes(avatarRow && avatarRow.size)}`
    : 'No picture — initials shown';

  const cover = pictureUrl(me.cover_media_id);
  $('#set-cover').style.backgroundImage = cover ? `url('${cover}')` : '';
  const coverRow = cover ? DB.media[me.cover_media_id] : null;
  $('#set-cover-name').textContent = cover
    ? `Cover stored on the site · ${formatBytes(coverRow && coverRow.size)}`
    : 'No cover — gradient shown';
  $('#btn-remove-avatar').disabled = !avatar;
  $('#btn-remove-cover').disabled = !cover;

  const stats = me.stats || {};
  $('#account-info').innerHTML = [
    ['Email', me.email],
    ['Handle', '@' + me.handle],
    ['Role', me.role],
    ['Status', me.status],
    ['Member since', me.joined ? new Date(at(me.joined)).toLocaleString() : 'unknown'],
    ['Sign-ins', String(me.login_count || 0)],
    ['Last sign-in', me.last_login_at ? new Date(at(me.last_login_at)).toLocaleString() : 'not yet recorded'],
    ['Posts', String(statOf(stats, 'posts'))],
    ['Reactions received', String(statOf(stats, 'reactions_received'))],
    ['Replies given', String(statOf(stats, 'comments_given'))],
    ['My uploaded files', `${statOf(stats, 'media')} · ${formatBytes(statOf(stats, 'bytes'))}`],
  ].map(([k, v]) => `<li><span>${esc(k)}</span><b>${esc(v)}</b></li>`).join('');
}

/* ============================================================
   8. RENDER + REFRESH
   ============================================================ */
function render(){
  if (!DB.me){
    $('#shell').hidden = true;
    $('#view-auth').hidden = false;
    return;
  }
  setAuthNotice('');
  $('#view-auth').hidden = true;
  $('#shell').hidden = false;

  renderChrome(DB.me);
  const views = { feed:'#view-feed', profile:'#view-profile', settings:'#view-settings', admin:'#view-admin' };
  if (UI.view === 'admin' && DB.me.role !== 'admin') UI.view = 'feed';
  Object.entries(views).forEach(([name, sel]) => { $(sel).hidden = name !== UI.view; });

  if (UI.view === 'feed') renderFeed(DB.me);
  if (UI.view === 'profile'){ renderProfile(DB.me); ensureMember(UI.profileId || DB.me.id); }
  if (UI.view === 'settings') renderSettings(DB.me);
  if (UI.view === 'admin'){ renderAdmin(DB.me); ensureAdmin(); }
  hydrateVideos();
}

function applyState(state){
  DB.me = state.me;
  DB.users = state.users || [];
  DB.posts = state.posts || [];
  DB.media = Object.fromEntries((state.media || []).map(m => [m.id, m]));
  DB.limits = state.limits || {};
  DB.member = null;
  DB.status = 'ready';
  DB.error = '';
  if (UI.view === 'admin' && DB.me.role !== 'admin') UI.view = 'feed';
  if (UI.view === 'profile') UI.profileId = DB.me.id;
}

async function refresh(){
  if (!DB.me) return boot();
  try {
    applyState(await API.state());
    if (UI.view === 'admin') DB.admin = null;
    render();
  } catch (err) { reportError(err); }
}

function reportError(err){
  // Only a session the server no longer accepts signs the visitor out. A 401 from a
  // password check means the typed secret was wrong, not that the session ended.
  const ended = err && ['login_required', 'invalid_session', 'account_suspended'].includes(err.code);
  if (ended) signOutLocally();
  toast(API.copyFor(err), 'err');
}

/* One in-flight mutation at a time keeps double clicks from creating duplicates. */
let busyDepth = 0;
async function guard(work){
  busyDepth += 1;
  document.body.classList.add('busy');
  try { await work(); }
  catch (err) { reportError(err); }
  finally {
    busyDepth -= 1;
    if (busyDepth === 0) document.body.classList.remove('busy');
  }
}

/* The counters are server-computed aggregates, so a reaction or reply folds the new
   numbers back in without re-downloading the feed. Trailing-debounced: one burst of
   clicks costs one read. */
let statsTimer = null;
function syncOwnStats(){
  if (!DB.me) return;
  clearTimeout(statsTimer);
  statsTimer = setTimeout(() => {
    statsTimer = null;
    API.ownStats()
      .then(({ stats }) => {
        if (!DB.me) return;
        DB.me.stats = stats;
        const cached = DB.member && DB.member.view;
        if (cached && cached.user_id === DB.me.id) cached.stats = stats;
        render();
      })
      .catch(() => {}); // a counter that missed a refresh is not worth interrupting the visitor
  }, 300);
}

function signOutLocally(){
  DB.me = null; DB.posts = []; DB.users = []; DB.media = {}; DB.admin = null; DB.member = null;
  DB.videoUrls = {}; DB.status = 'offline'; DB.error = '';
  UI.view = 'feed'; UI.profileId = null; UI.profileTab = 'posts'; UI.pickerFor = null;
  openComments.clear();
  clearDrafts();
  render();
}

/* ============================================================
   9. AUTH VIEW
   ============================================================ */
function setAuthNotice(text){
  const el = $('#auth-notice');
  el.textContent = text || '';
  el.hidden = !text;
}

function switchAuthTab(tab){
  $$('[data-auth-tab]').forEach(b => b.classList.toggle('active', b.dataset.authTab === tab));
  $('#form-login').hidden = tab !== 'login';
  $('#form-register').hidden = tab !== 'register';
}
$$('[data-auth-tab]').forEach(b => b.addEventListener('click', () => switchAuthTab(b.dataset.authTab)));

$('#form-login').addEventListener('submit', e => {
  e.preventDefault();
  const f = e.target;
  guard(async () => {
    await API.login({ email: f.email.value, password: f.password.value });
    applyState(await API.state());
    f.reset(); UI.view = 'feed';
    render();
    toast(`Welcome back, ${DB.me.name}.`, 'ok');
  });
});

$('#form-register').addEventListener('submit', e => {
  e.preventDefault();
  const f = e.target;
  if (f.password.value !== f.confirm.value) return toast('Passwords do not match.', 'err');
  const bio = f.bio.value.trim();
  guard(async () => {
    await API.register({ name: f.name.value, email: f.email.value, password: f.password.value });
    if (bio) await API.editProfile({ bio });
    applyState(await API.state());
    f.reset(); UI.view = 'feed';
    render();
    toast('Account created — your posts are stored on the site.', 'ok');
  });
});

$('#btn-logout').addEventListener('click', () => guard(async () => {
  try { await API.logout(); }
  catch (err) { if (err.status !== 401) throw err; }
  signOutLocally();
  toast('Signed out.');
}));

/* ============================================================
   10. NAVIGATION
   ============================================================ */
document.addEventListener('click', e => {
  const nav = e.target.closest('[data-nav]');
  if (!nav || !DB.me) return;
  if (nav.dataset.nav === 'profile'){ UI.profileId = DB.me.id; DB.member = null; }
  UI.view = nav.dataset.nav;
  render();
});

$('#search').addEventListener('input', e => { UI.query = e.target.value; if (UI.view !== 'feed') UI.view = 'feed'; render(); });
$('#sort').addEventListener('change', e => { UI.sort = e.target.value; render(); });
$$('[data-filter]').forEach(c => c.addEventListener('click', () => {
  UI.filter = c.dataset.filter;
  $$('[data-filter]').forEach(x => x.classList.toggle('active', x === c));
  render();
}));
$$('[data-reload]').forEach(b => b.addEventListener('click', () => {
  DB.admin = null; DB.member = null;
  guard(refresh);
}));

/* ============================================================
   11. COMPOSER + UPLOADS
   ============================================================ */
function limitsFor(kind){
  if (kind === 'video') return DB.limits.max_video_bytes || 25 * 1024 * 1024;
  if (kind === 'avatar' || kind === 'cover') return DB.limits.max_profile_bytes || 1024 * 1024;
  return DB.limits.max_image_bytes || 5 * 1024 * 1024;
}
const slotFor = file => (file.type.startsWith('video/') ? 'video' : file.type.startsWith('image/') ? 'image' : null);

/* Announce the file, put its bytes on the site's storage, then let the Function
   read them back and verify size and type before the file becomes usable. */
async function uploadFile(file, kind){
  const slot = kind || slotFor(file);
  if (!slot) throw new API.ApiError('unsupported_media_type', 415);
  const max = limitsFor(slot);
  if (file.size === 0 || file.size > max) throw new API.ApiError('invalid_media_size', 413);
  const intent = await API.uploadIntent({ kind: slot, size: file.size, contentType: file.type });
  const stored = await API.putFile(intent.signedUrl, file);
  if (!stored.ok) throw new API.ApiError('upload_failed', stored.status);
  const done = await API.completeUpload(intent.id);
  DB.media[done.id] = { id:done.id, owner:DB.me && DB.me.id, post:null, kind:done.kind, type:done.content_type, size:done.size };
  return done;
}

function renderDrafts(){
  const box = $('#media-preview');
  box.hidden = !UI.drafts.length;
  box.innerHTML = UI.drafts.map(d => `<div class="thumb" data-draft="${esc(d.key)}">
    ${d.kind === 'video'
      ? `<video src="${d.url}" muted></video><span class="badge-video">video</span>`
      : `<img src="${d.url}" alt="${esc(d.name)}" />`}
    ${d.state === 'waiting' ? '<span class="badge-video">uploading…</span>' : ''}
    ${d.state === 'failed' ? '<span class="badge-video">failed</span>' : ''}
    <button class="x" type="button" data-remove="${esc(d.key)}" title="Remove">×</button>
  </div>`).join('');
  const total = UI.drafts.reduce((n, d) => n + d.size, 0);
  $('#composer-hint').textContent = UI.drafts.length
    ? `${UI.drafts.length} file(s) · ${formatBytes(total)}${UI.drafts.some(d => d.state === 'waiting') ? ' · uploading' : ''}`
    : `images up to ${formatBytes(limitsFor('image'))} · video up to ${formatBytes(limitsFor('video'))}`;
}

function dropDraft(key){
  const draft = UI.drafts.find(d => d.key === key);
  if (!draft) return;
  URL.revokeObjectURL(draft.url);
  UI.drafts = UI.drafts.filter(d => d.key !== key);
  renderDrafts();
}
function clearDrafts(){
  UI.drafts.forEach(d => URL.revokeObjectURL(d.url));
  UI.drafts = [];
  renderDrafts();
}

$('#media-input').addEventListener('change', async e => {
  const files = [...e.target.files];
  e.target.value = '';
  for (const file of files){
    const draft = { key:uuid(), name:file.name, size:file.size, kind:slotFor(file), url:URL.createObjectURL(file), state:'waiting', id:null, promise:null };
    UI.drafts.push(draft);
    renderDrafts();
    draft.promise = uploadFile(file, draft.kind)
      .then(done => { draft.id = done.id; draft.size = done.size; draft.state = 'ready'; })
      .catch(err => {
        draft.state = 'failed';
        toast(`${file.name}: ${API.copyFor(err)}`, 'err');
      })
      .finally(renderDrafts);
    await draft.promise;
  }
});

$('#media-preview').addEventListener('click', e => {
  const key = e.target.closest('[data-remove]')?.dataset.remove;
  if (key) dropDraft(key);
});

$('#composer').addEventListener('submit', e => {
  e.preventDefault();
  if (!DB.me) return;
  const text = $('#post-text').value;
  guard(async () => {
    await Promise.allSettled(UI.drafts.map(d => d.promise));
    const ids = UI.drafts.filter(d => d.state === 'ready' && d.id).map(d => d.id);
    if (!text.trim() && !ids.length){
      toast(UI.drafts.some(d => d.state === 'waiting') ? 'Files are still uploading — one moment.' : 'Write something or attach a file first.', 'err');
      return;
    }
    const result = await API.createPost({ body: text.trim(), media: ids }, uuid());
    if (result.media_pending && result.media_pending.length){
      await API.attachMedia(result.post.id, result.media_pending).catch(() => {});
    }
    $('#post-text').value = '';
    clearDrafts();
    await refresh();
    toast(ids.length ? 'Post and files published.' : 'Post published.', 'ok');
  });
});

$('#post-text').addEventListener('keydown', e => {
  if ((e.ctrlKey || e.metaKey) && e.key === 'Enter'){ e.preventDefault(); $('#composer').requestSubmit(); }
});

/* ============================================================
   12. POST ACTIONS
   ============================================================ */
function addComment(postId, text){
  const post = DB.posts.find(p => p.id === postId);
  if (!post || !DB.me || !text.trim()) return;
  guard(async () => {
    const { comment } = await API.addComment(postId, { body: text.trim() }, uuid());
    post.comments = post.comments || [];
    post.comments.push({ id:comment.id, author:comment.author_id, text:comment.body, time:comment.created_at });
    openComments.add(postId);
    syncOwnStats();
    render();
  });
}

async function setReaction(postId, key){
  const post = DB.posts.find(p => p.id === postId);
  if (!post || !DB.me || !REACT[key]) return;
  const snapshot = post.reactions || {};
  const had = snapshot[DB.me.id] || null;
  const next = had === key ? null : key;
  const optimistic = { ...snapshot };
  if (next === null) delete optimistic[DB.me.id]; else optimistic[DB.me.id] = next;
  post.reactions = optimistic;
  UI.pickerFor = null;
  render();
  try {
    const result = await API.setReaction(postId, next);
    post.reactions = result.reactions || {};
    syncOwnStats();
  } catch (err) {
    post.reactions = snapshot;
    toast(API.copyFor(err), 'err');
  }
  render();
}

document.addEventListener('click', e => {
  if (UI.pickerFor && !e.target.closest('.react-group')){ UI.pickerFor = null; render(); }
  const btn = e.target.closest('[data-act]');
  if (!btn) return;
  const act = btn.dataset.act;

  if (act === 'open-profile'){
    if (!DB.me) return;
    const id = btn.dataset.uid;
    if (userById(id)){
      UI.profileId = id; UI.view = 'profile'; UI.profileTab = 'posts'; UI.pickerFor = null;
      DB.member = null;
      render();
    }
    return;
  }
  if (!DB.me) return;
  const id = btn.dataset.id;

  if (act === 'react') setReaction(id, 'like');
  else if (act === 'react-set') setReaction(id, btn.dataset.key);
  else if (act === 'picker'){ UI.pickerFor = UI.pickerFor === id ? null : id; render(); }
  else if (act === 'toggle-comments'){
    openComments.has(id) ? openComments.delete(id) : openComments.add(id);
    render();
  }
  else if (act === 'drop-comment'){
    const post = DB.posts.find(p => p.id === id);
    if (!post) return;
    const cid = btn.dataset.cid;
    guard(async () => {
      await API.deleteComment(cid);
      post.comments = (post.comments || []).filter(c => c.id !== cid);
      syncOwnStats();
      render();
    });
  }
  else if (act === 'delete'){
    if (!confirm('Delete this post and its files for every visitor?')) return;
    guard(async () => {
      await API.deletePost(id);
      DB.admin = null; DB.member = null;
      await refresh();
      toast('Post deleted.');
    });
  }
  else if (act === 'share'){
    const post = DB.posts.find(p => p.id === id);
    const text = post ? post.text : '';
    if (!text) return toast('That post has no text to copy.', 'err');
    if (navigator.clipboard) navigator.clipboard.writeText(text).then(() => toast('Post text copied.', 'ok'), () => toast('Clipboard blocked by the browser.', 'err'));
    else toast('Clipboard unavailable in this context.', 'err');
  }
  else if (DB.me.role === 'admin'){
    if (act === 'a-role'){
      const target = btn.dataset.uid;
      const member = (DB.admin && DB.admin.members || []).find(u => u.id === target);
      guard(async () => {
        await API.adminSetRole(target, member && member.role === 'admin' ? 'member' : 'admin');
        DB.admin = null;
        await refresh();
        toast('Role updated.', 'ok');
      });
    }
    else if (act === 'a-status'){
      const target = btn.dataset.uid;
      const member = (DB.admin && DB.admin.members || []).find(u => u.id === target);
      guard(async () => {
        await API.adminSetStatus(target, member && member.status === 'active' ? 'suspended' : 'active');
        DB.admin = null;
        await refresh();
        toast('Account status updated.', 'ok');
      });
    }
    else if (act === 'a-del-user'){
      if (btn.disabled) return;
      const target = btn.dataset.uid;
      const member = (DB.admin && DB.admin.members || []).find(u => u.id === target);
      if (!confirm(`Delete ${member ? member.name : 'this member'}, their posts and files? This cannot be undone.`)) return;
      guard(async () => {
        await API.adminDeleteMember(target);
        DB.admin = null; DB.member = null;
        await refresh();
        toast('Account removed.');
      });
    }
    else if (act === 'a-del-post'){
      if (!confirm('Delete this post for everyone?')) return;
      guard(async () => {
        await API.deletePost(id);
        DB.admin = null; DB.member = null;
        await refresh();
        toast('Post removed.');
      });
    }
  }
});

/* Hover a reaction button briefly to open the picker (the ⌄ caret covers touch). */
let hoverTimer = null;
document.addEventListener('mouseover', e => {
  const group = e.target.closest('.react-group');
  if (!group) return;
  clearTimeout(hoverTimer);
  const id = group.dataset.pickerAnchor;
  hoverTimer = setTimeout(() => { if (UI.pickerFor !== id){ UI.pickerFor = id; render(); } }, 500);
});
document.addEventListener('mouseout', e => {
  const group = e.target.closest('.react-group');
  if (!group || (e.relatedTarget && group.contains(e.relatedTarget))) return;
  clearTimeout(hoverTimer);
  const id = group.dataset.pickerAnchor;
  hoverTimer = setTimeout(() => { if (UI.pickerFor === id){ UI.pickerFor = null; render(); } }, 300);
});

$$('#profile-tabs .chip').forEach(c => c.addEventListener('click', () => { UI.profileTab = c.dataset.tab; render(); }));

document.addEventListener('submit', e => {
  const form = e.target.closest('[data-comment-form]');
  if (!form) return;
  e.preventDefault();
  const input = form.querySelector('input');
  addComment(form.dataset.commentForm, input.value);
  input.value = '';
});

/* ============================================================
   13. LIGHTBOX
   ============================================================ */
document.addEventListener('click', e => {
  const box = $('#lightbox');
  const img = e.target.closest('img[data-lightbox]');
  if (img){
    box.querySelector('.lightbox-inner').innerHTML = `<img src="${img.dataset.lightbox}" alt="expanded view" />`;
    box.hidden = false;
    return;
  }
  if (!box.hidden && !e.target.closest('.lightbox-inner')) box.hidden = true;
});
document.addEventListener('keydown', e => {
  if (e.key !== 'Escape') return;
  $('#lightbox').hidden = true;
  if (UI.pickerFor){ UI.pickerFor = null; render(); }
});

/* ============================================================
   14. PROFILE EDIT, PICTURES, PASSWORD
   ============================================================ */
$('#profile-edit').addEventListener('submit', e => {
  e.preventDefault();
  if (!DB.me) return;
  const f = e.target;
  const files = { avatar:f.avatar.files[0], cover:f.cover.files[0] };
  guard(async () => {
    await API.editProfile({ name: f.name.value, bio: f.bio.value });
    for (const slot of ['avatar', 'cover']){
      const file = files[slot];
      if (!file) continue;
      if (!file.type.startsWith('image/')){ toast(`A ${slot} must be an image file.`, 'err'); continue; }
      const done = await uploadFile(file, slot);
      await API.applyUpload(done.id, slot);
    }
    f.avatar.value = '';
    f.cover.value = '';
    DB.member = null;
    await refresh();
    toast('Profile updated.', 'ok');
  });
});

function updatePicture(slot, file){
  if (!DB.me || !file) return;
  if (!file.type.startsWith('image/')) return toast('Pick an image file.', 'err');
  guard(async () => {
    const done = await uploadFile(file, slot);
    await API.applyUpload(done.id, slot);
    DB.member = null;
    await refresh();
    toast(slot === 'cover' ? 'Cover updated.' : 'Profile picture updated.', 'ok');
  });
}

[['#quick-avatar', 'avatar'], ['#quick-cover', 'cover'],
 ['#set-avatar-input', 'avatar'], ['#set-cover-input', 'cover']].forEach(([sel, slot]) => {
  $(sel).addEventListener('change', e => {
    const file = e.target.files[0];
    e.target.value = '';
    updatePicture(slot, file);
  });
});

function clearPicture(slot){
  if (!DB.me) return;
  guard(async () => {
    await API.removePicture(slot);
    DB.member = null;
    await refresh();
    toast(slot === 'cover' ? 'Cover removed.' : 'Picture removed.');
  });
}
$('#btn-remove-avatar').addEventListener('click', () => clearPicture('avatar'));
$('#btn-remove-cover').addEventListener('click', () => clearPicture('cover'));

$('#form-password').addEventListener('submit', e => {
  e.preventDefault();
  const f = e.target;
  if (f.next.value !== f.confirm.value) return toast('New passwords do not match.', 'err');
  guard(async () => {
    await API.changePassword({ currentPassword: f.current.value, nextPassword: f.next.value });
    f.reset();
    DB.admin = null;
    await refresh();
    toast('Password updated — other devices are signed out.', 'ok');
  });
});

$('#btn-reset-pass').addEventListener('click', () => {
  if (!DB.me || DB.me.role !== 'admin') return;
  const target = $('#reset-user').value;
  const member = (DB.admin && DB.admin.members || []).find(u => u.id === target);
  if (!member) return;
  if (!confirm(`Set a new password for ${member.name}? Their current password stops working.`)) return;
  const password = $('#reset-pass').value;
  guard(async () => {
    await API.adminResetPassword(target, password);
    $('#reset-pass').value = '';
    DB.admin = null;
    await refresh();
    toast(`${member.name}'s password was reset.`, 'ok');
  });
});

/* ============================================================
   15. ADMIN DATA TOOLS
   ============================================================ */
$('#member-search').addEventListener('input', render);
$('#post-search').addEventListener('input', render);

$('#btn-export').addEventListener('click', () => {
  const a = document.createElement('a');
  a.href = API.adminExportUrl;
  a.download = 'loopr-export-' + new Date().toISOString().slice(0, 10) + '.json';
  document.body.appendChild(a);
  a.click();
  a.remove();
  toast('Backup download started.', 'ok');
});

$('#btn-prune').addEventListener('click', () => guard(async () => {
  const result = await API.adminPrune();
  DB.admin = null;
  await refresh();
  toast(result.removed ? `Dropped ${result.removed} unused file(s), ${formatBytes(result.bytes)}.` : 'No unused files found.', result.removed ? 'ok' : '');
}));

/* ============================================================
   16. BOOT
   ============================================================ */
async function boot(){
  DB.status = 'booting';
  render();
  try {
    applyState(await API.state());
    UI.profileId = DB.me.id;
    render();
  } catch (err) {
    DB.me = null;
    DB.status = 'offline';
    render();
    /* Backend missing or unavailable: say exactly which, never show fake data. */
    if (err.status !== 401){
      DB.error = API.copyFor(err);
      setAuthNotice(DB.error);
    }
  }
}

renderDrafts();
boot();
})();
